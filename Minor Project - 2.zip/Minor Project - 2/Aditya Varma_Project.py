# ------------------------
# 1. Imports and settings
# ------------------------
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler
import warnings
warnings.filterwarnings('ignore')

sns.set_theme(style="whitegrid")
print("Libraries imported successfully.")

# ---------------------------------------
# 2. Load dataset and initial inspection
# ---------------------------------------
df = pd.read_csv("D:\\Unlox\\May\\Minor Project - 2\\adult.csv")
df.columns = [c.replace('.', '_') for c in df.columns]
df['income'] = df['income'].str.strip()
df.rename(columns={'fnlwgt': 'final_weight'}, inplace=True)
print("Dataset loaded into dataframe.")

df.head()
print(df.shape)
df.info()

df.describe()

# --------------------------
# 3. Missing value handling
# --------------------------
df.replace(' ?', np.nan, inplace=True)
df.isnull().sum()

for col in df.select_dtypes(include='object').columns:
    if df[col].isnull().sum() > 0:
        df[col].fillna(df[col].mode()[0], inplace=True)

for col in df.select_dtypes(include=np.number).columns:
    if df[col].isnull().sum() > 0:
        df[col].fillna(df[col].mean(), inplace=True)

print("Missing values handled successfully.")

# ---------------------------------------
# 4. Duplicate removal and feature types
# ---------------------------------------
df.duplicated().sum()
df.drop_duplicates(inplace=True)
print("Duplicate rows removed successfully.")

num_cols = df.select_dtypes(include=['int64', 'float64']).columns
cat_cols = df.select_dtypes(include=['object']).columns
print(num_cols)
print(cat_cols)
print("Numerical and categorical columns separated.")

# --------------------------------
# 5. Univariate exploratory plots
# --------------------------------
for col in num_cols:
    plt.figure(figsize=(10, 5))
    sns.histplot(df[col], kde=True)
    plt.title(f'Distribution of {col}')
    plt.xlabel(col)
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.show()

for col in num_cols:
    plt.figure(figsize=(10, 5))
    sns.boxplot(x=df[col])
    plt.title(f'Boxplot of {col}')
    plt.xlabel(col)
    plt.tight_layout()
    plt.show()

# ----------------------------------
# 6. Outlier detection and clipping
# ----------------------------------
for col in ['capital_gain', 'capital_loss', 'final_weight']:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    print(f"{col} — Lower: {lower:.2f}, Upper: {upper:.2f}")
    df[col] = df[col].clip(lower, upper)

print("Outliers treated successfully.")

# ------------------------------------
# 7. Correlation and bivariable plots
# ------------------------------------
corr = df.corr(numeric_only=True)
plt.figure(figsize=(10, 7))
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.tight_layout()
plt.show()

sns.scatterplot(x='age', y='hours_per_week', hue='income', data=df)
plt.title('Age vs Hours Per Week by Income')
plt.xlabel('Age')
plt.ylabel('Hours Per Week')
plt.tight_layout()
plt.show()

sns.boxplot(x='income', y='hours_per_week', data=df)
plt.title('Hours Per Week by Income')
plt.xlabel('Income')
plt.ylabel('Hours Per Week')
plt.tight_layout()
plt.show()

# -----------------------------------------
# 8. Categorical income distribution plots
# -----------------------------------------
for col in ['education', 'occupation', 'sex']:
    grp = df.groupby([col, 'income']).size().unstack(fill_value=0)
    pct = grp.div(grp.sum(axis=1), axis=0) * 100
    pct.plot(kind='bar', stacked=True, figsize=(10, 5), colormap='Set2')
    plt.title(f'Income Distribution by {col} (%)')
    plt.xlabel(col)
    plt.ylabel('Percentage (%)')
    plt.xticks(rotation=30)
    plt.tight_layout()
    plt.show()

# -----------------------------------
# 9. Feature engineering: age groups
# -----------------------------------
df['age_group'] = pd.cut(
    df['age'],
    bins=[0, 25, 35, 50, 65, 100],
    labels=['<25', '25-35', '35-50', '50-65', '65+'],
    right=False
)

grp = df.groupby(['age_group', 'income']).size().unstack(fill_value=0)
pct = grp.div(grp.sum(axis=1), axis=0) * 100
pct.plot(kind='bar', stacked=True, figsize=(10, 5), colormap='Set2')
plt.title('Income Distribution by Age Group (%)')
plt.xlabel('Age Group')
plt.ylabel('Percentage (%)')
plt.xticks(rotation=15)
plt.tight_layout()
plt.show()

# ---------------------------------
# 10. Encode categorical variables
# ---------------------------------
le = LabelEncoder()
for col in cat_cols:
    df[col] = le.fit_transform(df[col].astype(str))

print("Categorical values converted into numbers.")


# -----------------------------
# 11. Scale numerical features
# -----------------------------
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df[num_cols])
print("Features standardized successfully.")


# ------------------
# 12. Final summary
# ------------------
print("Final shape:", df.shape)
df.head(2)
