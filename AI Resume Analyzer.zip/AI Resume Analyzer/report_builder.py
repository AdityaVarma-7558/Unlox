import io
from datetime import date
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import inch


def build_report(target_role: str, top_matches: list[dict], resume_skills: list[str], roadmap: list[dict], ai_feedback: str = "") -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, topMargin=0.6 * inch, bottomMargin=0.6 * inch)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph("Resume Analysis Report", styles["Title"]))
    story.append(Paragraph(f"Generated on {date.today().strftime('%d %B %Y')}", styles["Normal"]))
    story.append(Spacer(1, 16))

    story.append(Paragraph(f"Target Role: {target_role}", styles["Heading2"]))
    top_score = top_matches[0]["score"] if top_matches else 0
    story.append(Paragraph(f"Match Score: {top_score}%", styles["Normal"]))
    story.append(Spacer(1, 12))

    story.append(Paragraph("Skills Found in Resume", styles["Heading2"]))
    skills_text = ", ".join(resume_skills) if resume_skills else "No skills detected"
    story.append(Paragraph(skills_text, styles["Normal"]))
    story.append(Spacer(1, 12))

    story.append(Paragraph("Recommended Roles", styles["Heading2"]))
    table_data = [["Role", "Score", "Category"]]
    for match in top_matches:
        table_data.append([match["role"], f"{match['score']}%", match["category"]])
    table = Table(table_data, colWidths=[3 * inch, 1 * inch, 2 * inch])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E79")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F2F2")]),
    ]))
    story.append(table)
    story.append(Spacer(1, 12))

    if top_matches:
        missing = top_matches[0]["missing_skills"]
        story.append(Paragraph("Missing Skills for Target Role", styles["Heading2"]))
        missing_text = ", ".join(missing) if missing else "None - great match!"
        story.append(Paragraph(missing_text, styles["Normal"]))
        story.append(Spacer(1, 12))

    if roadmap:
        story.append(Paragraph("Suggested Learning Roadmap", styles["Heading2"]))
        roadmap_data = [["Week", "Focus"]]
        for item in roadmap:
            roadmap_data.append([f"Week {item['week']}", f"{item['skill']}: {item['focus']}"])
        roadmap_table = Table(roadmap_data, colWidths=[1 * inch, 5 * inch])
        roadmap_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E79")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        story.append(roadmap_table)
        story.append(Spacer(1, 12))

    if ai_feedback:
        story.append(Paragraph("AI Feedback", styles["Heading2"]))
        story.append(Paragraph(ai_feedback, styles["Normal"]))
        story.append(Spacer(1, 12))

    story.append(Spacer(1, 20))
    disclaimer = ("This report is an automated estimate based on keyword and semantic matching. "
                  "It does not represent a hiring decision. Missing keywords do not always mean missing ability.")
    story.append(Paragraph(disclaimer, styles["Italic"]))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()
