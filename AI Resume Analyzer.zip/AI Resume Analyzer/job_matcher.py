import csv
from pathlib import Path
from functools import lru_cache
from sentence_transformers import SentenceTransformer, util

DEFAULT_ROLES_PATH = Path(__file__).parent / "data" / "job_roles.csv"
MODEL_NAME = "all-MiniLM-L6-v2"


@lru_cache(maxsize=1)
def get_model():
    return SentenceTransformer(MODEL_NAME)


def load_job_roles(path: str = DEFAULT_ROLES_PATH) -> list[dict]:
    roles = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            skills = [s.strip() for s in row["required_skills"].split(",") if s.strip()]
            roles.append({
                "role": row["role"].strip(),
                "required_skills": skills,
                "category": row["category"].strip(),
            })
    return roles


def match_roles(resume_skills: list[str], job_roles: list[dict] = None, top_n: int = 5) -> list[dict]:
    if job_roles is None:
        job_roles = load_job_roles()

    model = get_model()
    resume_text = ", ".join(resume_skills) if resume_skills else ""
    resume_embedding = model.encode(resume_text, convert_to_tensor=True)

    role_texts = [", ".join(role["required_skills"]) for role in job_roles]
    role_embeddings = model.encode(role_texts, convert_to_tensor=True)
    similarities = util.cos_sim(resume_embedding, role_embeddings)[0]

    results = []
    for role, similarity in zip(job_roles, similarities):
        score = round(max(0.0, similarity.item()) * 100, 1)

        resume_skill_set = set(s.lower() for s in resume_skills)
        required_set = set(s.lower() for s in role["required_skills"])
        matched = sorted(resume_skill_set & required_set)
        missing = sorted(required_set - resume_skill_set)

        results.append({
            "role": role["role"],
            "category": role["category"],
            "score": score,
            "matched_skills": matched,
            "missing_skills": missing,
        })

    results.sort(key=lambda r: r["score"], reverse=True)
    return results[:top_n]
