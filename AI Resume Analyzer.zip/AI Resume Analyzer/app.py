import os
import streamlit as st
import plotly.express as px
from dotenv import load_dotenv

from resume_parser import extract_text, ResumeParseError
from text_cleaner import clean_text
from skill_extractor import extract_skills, flatten_skills, load_skill_dictionary
from job_matcher import match_roles, load_job_roles
from roadmap_generator import generate_roadmap, generate_ai_feedback
from report_builder import build_report

load_dotenv()

st.set_page_config(page_title="AI Resume Analyzer", layout="wide")

MAX_FILE_SIZE_MB = 5

st.title("AI Resume Analyzer & Job Recommendation System")
st.caption("Upload your resume to see how well it matches different job roles, and get a personalized learning roadmap.")

with st.sidebar:
    st.header("Settings")
    job_roles = load_job_roles()
    role_names = [r["role"] for r in job_roles]
    target_role = st.selectbox("Target role", role_names)
    top_n = st.slider("Number of roles to compare", min_value=3, max_value=len(role_names), value=5)
    use_ai_feedback = st.checkbox("Enable AI-generated feedback (uses Gemini API)", value=False)
    st.divider()
    st.caption("Your resume is processed in-memory and is never saved to disk.")

uploaded_file = st.file_uploader("Upload your resume (PDF or DOCX)", type=["pdf", "docx"])

if uploaded_file is not None:
    file_bytes = uploaded_file.read()
    size_mb = len(file_bytes) / (1024 * 1024)

    if size_mb > MAX_FILE_SIZE_MB:
        st.error(f"File is {size_mb:.1f}MB. Please upload a file under {MAX_FILE_SIZE_MB}MB.")
        st.stop()

    st.success(f"Uploaded: {uploaded_file.name} ({size_mb:.2f} MB)")

    try:
        with st.spinner("Extracting resume text..."):
            raw_text = extract_text(file_bytes, uploaded_file.name)
            cleaned = clean_text(raw_text)
    except ResumeParseError as e:
        st.error(str(e))
        st.stop()

    with st.spinner("Identifying skills..."):
        skill_dict = load_skill_dictionary()
        categorized_skills = extract_skills(cleaned, skill_dict)
        resume_skills = flatten_skills(categorized_skills)

    if not resume_skills:
        st.warning("No known skills were detected. The skill dictionary may need expanding for this resume, or the file could not be parsed cleanly.")

    st.subheader("Extracted Skills")
    if categorized_skills:
        cols = st.columns(len(categorized_skills))
        for col, (category, skills) in zip(cols, categorized_skills.items()):
            with col:
                st.markdown(f"**{category}**")
                for s in skills:
                    st.markdown(f"- {s}")
    else:
        st.info("No skills detected yet.")

    with st.spinner("Matching against job roles..."):
        matches = match_roles(resume_skills, job_roles, top_n=top_n)

    st.subheader("Match Scores by Role")
    fig = px.bar(
        x=[m["score"] for m in matches],
        y=[m["role"] for m in matches],
        orientation="h",
        labels={"x": "Match Score (%)", "y": "Role"},
    )
    fig.update_layout(yaxis={"categoryorder": "total ascending"})
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Top Recommended Roles")
    for m in matches[:3]:
        st.markdown(f"**{m['role']}** — {m['score']}% match ({m['category']})")

    target_match = next((m for m in matches if m["role"] == target_role), None)
    if target_match is None:
        target_matches = match_roles(resume_skills, [r for r in job_roles if r["role"] == target_role], top_n=1)
        target_match = target_matches[0] if target_matches else None

    if target_match:
        st.subheader(f"Skill Gap Analysis — {target_role}")
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**Skills you already have**")
            if target_match["matched_skills"]:
                for s in target_match["matched_skills"]:
                    st.markdown(f"- {s}")
            else:
                st.markdown("_None matched yet_")
        with col2:
            st.markdown("**Missing skills**")
            if target_match["missing_skills"]:
                for s in target_match["missing_skills"]:
                    st.markdown(f"- {s}")
            else:
                st.markdown("_No gaps — great match!_")

        roadmap = generate_roadmap(target_match["missing_skills"])
        if roadmap:
            st.subheader("Suggested Learning Roadmap")
            for item in roadmap:
                st.markdown(f"**Week {item['week']}: {item['skill']}** — {item['focus']}")

        ai_feedback = ""
        if use_ai_feedback:
            with st.spinner("Generating AI feedback..."):
                ai_feedback = generate_ai_feedback(resume_skills, target_role, target_match["missing_skills"])
            if ai_feedback:
                st.subheader("AI Feedback")
                st.write(ai_feedback)

        st.divider()
        pdf_bytes = build_report(target_role, matches, resume_skills, roadmap, ai_feedback)
        st.download_button(
            label="Download Analysis Report (PDF)",
            data=pdf_bytes,
            file_name="resume_analysis_report.pdf",
            mime="application/pdf",
        )

    st.caption("This tool provides guidance only, not hiring decisions. Match scores are estimates based on keyword and semantic similarity.")
else:
    st.info("Upload a resume to get started.")
