import re
import csv
from pathlib import Path

DEFAULT_DICT_PATH = Path(__file__).parent / "data" / "skill_dictionary.csv"


def load_skill_dictionary(path: str = DEFAULT_DICT_PATH) -> list[dict]:
    skills = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            aliases = [a.strip() for a in row["aliases"].split("|") if a.strip()]
            skills.append({
                "skill": row["skill"].strip(),
                "category": row["category"].strip(),
                "aliases": aliases,
            })
    return skills


def extract_skills(cleaned_text: str, skill_dict: list[dict] = None) -> dict:
    if skill_dict is None:
        skill_dict = load_skill_dictionary()

    found = {}
    for entry in skill_dict:
        variants = [entry["skill"]] + entry["aliases"]
        for variant in variants:
            pattern = r"(?<!\w)" + re.escape(variant) + r"(?!\w)"
            if re.search(pattern, cleaned_text):
                found[entry["skill"]] = entry["category"]
                break

    categorized = {}
    for skill, category in found.items():
        categorized.setdefault(category, []).append(skill)

    for category in categorized:
        categorized[category].sort()

    return categorized


def flatten_skills(categorized_skills: dict) -> list[str]:
    flat = []
    for skills in categorized_skills.values():
        flat.extend(skills)
    return sorted(flat)
