import os
import json

LEARNING_RESOURCES = {
    "docker": "Learn container basics, then containerize a small app",
    "kubernetes": "Learn pod/deployment/service concepts on a local cluster (minikube)",
    "fastapi": "Build a small REST API with FastAPI covering CRUD and validation",
    "aws": "Complete AWS Cloud Practitioner fundamentals, then deploy a project on EC2/S3",
    "sql": "Practice joins, aggregations, and query optimization on a sample database",
    "machine learning": "Complete a supervised learning course, then build an end-to-end model",
    "deep learning": "Learn neural network fundamentals, then build a project with PyTorch",
    "nlp": "Learn tokenization, embeddings, and transformer basics",
    "llm": "Learn prompt engineering and basic RAG pipeline construction",
    "rag": "Build a small retrieval-augmented generation pipeline with a vector store",
    "computer vision": "Learn image processing basics, then build a CNN classifier",
    "git": "Practice branching, merging, and pull request workflows",
    "react": "Build a small multi-page app with React and component state",
}

DEFAULT_TOPIC = "Build a small hands-on project focused on this skill"


def generate_roadmap(missing_skills: list[str], weeks: int = 4) -> list[dict]:
    if not missing_skills:
        return []

    prioritized = missing_skills[:weeks] if len(missing_skills) >= weeks else missing_skills
    roadmap = []
    for i, skill in enumerate(prioritized, start=1):
        topic = LEARNING_RESOURCES.get(skill.lower(), DEFAULT_TOPIC)
        roadmap.append({
            "week": i,
            "skill": skill,
            "focus": topic,
        })

    remaining = missing_skills[weeks:]
    if remaining:
        roadmap.append({
            "week": weeks + 1,
            "skill": ", ".join(remaining),
            "focus": "Continue building familiarity with remaining skills",
        })

    return roadmap


def generate_ai_feedback(resume_skills: list[str], target_role: str, missing_skills: list[str], api_key: str = None) -> str:
    api_key = api_key or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return ""

    try:
        import google.generativeai as genai

        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-2.0-flash")

        prompt = f"""A student applying for the role of {target_role} has these resume skills:
{', '.join(resume_skills) if resume_skills else 'none detected'}

Missing skills for this role: {', '.join(missing_skills) if missing_skills else 'none'}

Give 3-4 short, specific, encouraging bullet points of resume improvement advice.
Do not repeat the skill list back. Do not mention age, gender, or any personal attributes.
Keep the entire response under 120 words."""

        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"AI feedback unavailable: {e}"
