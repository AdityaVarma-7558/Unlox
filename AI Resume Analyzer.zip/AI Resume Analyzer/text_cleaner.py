import re

PROTECTED_TOKENS = ["c++", "c#", ".net", "node.js", "asp.net", "d3.js", "vue.js", "react.js"]


def clean_text(raw_text: str) -> str:
    text = raw_text.lower()

    placeholders = {}
    for i, token in enumerate(PROTECTED_TOKENS):
        if token in text:
            placeholder = f"__protected_{i}__"
            placeholders[placeholder] = token
            text = text.replace(token, placeholder)

    text = re.sub(r"[^\w\s.+#_-]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    for placeholder, token in placeholders.items():
        text = text.replace(placeholder, token)

    return text


def extract_sections(raw_text: str) -> dict:
    section_headers = {
        "education": r"education|academic background|qualification",
        "skills": r"skills|technical skills|core competencies",
        "experience": r"experience|work history|employment",
        "projects": r"projects|academic projects|personal projects",
    }

    lines = raw_text.split("\n")
    sections = {key: [] for key in section_headers}
    current_section = None

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        matched = False
        for section, pattern in section_headers.items():
            if re.fullmatch(pattern, stripped.lower()) or (
                len(stripped) < 40 and re.match(pattern, stripped.lower())
            ):
                current_section = section
                matched = True
                break

        if not matched and current_section:
            sections[current_section].append(stripped)

    return {k: "\n".join(v) for k, v in sections.items()}
