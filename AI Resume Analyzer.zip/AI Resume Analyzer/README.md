# AI Resume Analyzer & Job Recommendation System

An NLP-based Streamlit application that analyzes a resume against job roles, scores the match, identifies skill gaps, and generates a learning roadmap.

## Features

- Upload PDF or DOCX resumes (processed fully in-memory, never saved to disk)
- Skill extraction via a controlled dictionary with alias matching (e.g. "ML" -> "machine learning")
- Semantic job matching using Sentence Transformers (`all-MiniLM-L6-v2`) + cosine similarity
- Top-N role recommendations with match scores
- Skill gap analysis for a selected target role
- Rule-based learning roadmap, with optional Gemini-powered AI feedback
- Downloadable PDF analysis report

## Setup

```bash
python -m venv venv
venv\Scripts\activate          # Windows
pip install -r requirements.txt
```

Copy `.env` and add your Gemini API key (optional, only needed if you enable AI feedback):

```
GEMINI_API_KEY=your_key_here
```

## Run

```bash
streamlit run app.py
```

## Project Structure

```
ai_resume_analyzer/
|-- app.py                  Streamlit dashboard
|-- resume_parser.py        PDF/DOCX text extraction (in-memory)
|-- text_cleaner.py         Text normalization + section detection
|-- skill_extractor.py      Skill dictionary matching
|-- job_matcher.py          Sentence Transformer matching + ranking
|-- roadmap_generator.py    Roadmap generation + optional Gemini feedback
|-- report_builder.py       PDF report generation
|-- requirements.txt
|-- data/
|   |-- job_roles.csv       Job role -> required skills dataset
|   |-- skill_dictionary.csv  Controlled skill list with aliases
|-- sample_resumes/
|-- reports/
|-- tests/
```