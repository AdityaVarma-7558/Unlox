import io
from pypdf import PdfReader
from docx import Document


class ResumeParseError(Exception):
    pass


def extract_text(file_bytes: bytes, filename: str) -> str:
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if ext == "pdf":
        return _extract_from_pdf(file_bytes)
    elif ext == "docx":
        return _extract_from_docx(file_bytes)
    else:
        raise ResumeParseError(f"Unsupported file type: .{ext}. Only .pdf and .docx are supported.")


def _extract_from_pdf(file_bytes: bytes) -> str:
    try:
        reader = PdfReader(io.BytesIO(file_bytes))
        pages = [page.extract_text() or "" for page in reader.pages]
        text = "\n".join(pages)
    except Exception as e:
        raise ResumeParseError(f"Failed to extract text from PDF: {e}")

    if not text.strip():
        raise ResumeParseError("No extractable text found in this PDF. It may be a scanned image.")
    return text


def _extract_from_docx(file_bytes: bytes) -> str:
    try:
        doc = Document(io.BytesIO(file_bytes))
        paragraphs = [p.text for p in doc.paragraphs]
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    paragraphs.append(cell.text)
        text = "\n".join(paragraphs)
    except Exception as e:
        raise ResumeParseError(f"Failed to extract text from DOCX: {e}")

    if not text.strip():
        raise ResumeParseError("No extractable text found in this DOCX file.")
    return text
