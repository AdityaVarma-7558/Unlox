import streamlit as st
import tensorflow as tf
from PIL import Image, ImageOps
import numpy as np

@st.cache_resource
def load_trained_model():
    return tf.keras.models.load_model('cnn_model.h5')

def process_image(image):
    gray_image = image.convert('L')
    inverted_image = ImageOps.invert(gray_image)
    resized_image = inverted_image.resize((28, 28))
    img_array = np.array(resized_image) / 255.0
    img_array = img_array.reshape(1, 28, 28, 1)
    return img_array

def main():
    st.title("CNN Image Classifier")

    model = load_trained_model()

    uploaded_file = st.file_uploader("Upload an image...", type=["jpg", "png", "jpeg"])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption='Uploaded Image', use_container_width=True)
        
        if st.button('Predict'):
            processed_img = process_image(image)
            prediction = model.predict(processed_img)
            predicted_class = np.argmax(prediction)
            st.write(f"Predicted Class: {predicted_class}")

if __name__ == '__main__':
    main()