import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

df = pd.read_csv(r"D:\Unlox\June\Minor Project - 5\train.csv")

print("\n" "============================================================")
print("              DATASET INITIALIZATION")
print("============================================================")
print("First 5 rows of the dataset:")
print(df.head())
print("\nTarget Variable Distribution (price_range):")
print(df['price_range'].value_counts().to_string())
print("------------------------------------------------------------" "\n")

plt.figure(figsize=(10, 6))
plt.title("RAM Distribution Across Price Ranges")
sns.boxplot(x='price_range', y='ram', data=df)
plt.xlabel("Price Range (0: Low, 1: Medium, 2: High, 3: Flagship)")
plt.ylabel("RAM (Megabytes)")
plt.show()

pair_plot = sns.pairplot(df[['battery_power', 'ram', 'int_memory', 'price_range']], hue='price_range')
pair_plot.fig.suptitle("Hardware Specifications Pairplot by Price Tier", y=1.02)
plt.show()

X = df.drop('price_range', axis=1)
y = df['price_range']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

tuned_model = GradientBoostingClassifier(
    n_estimators=150, 
    learning_rate=0.05, 
    max_depth=4, 
    random_state=42
)
tuned_model.fit(X_train, y_train)

y_pred = tuned_model.predict(X_test)

print("\n" "============================================================")
print("          GRADIENT BOOSTING MODEL METRICS")
print("============================================================")
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

train_acc = tuned_model.score(X_train, y_train)
test_acc = tuned_model.score(X_test, y_test)
print(f"Training Accuracy : {train_acc:.4f} ({train_acc * 100:.2f}%)")
print(f"Testing Accuracy  : {test_acc:.4f} ({test_acc * 100:.2f}%)")
print("------------------------------------------------------------" "\n")

importances = tuned_model.feature_importances_
plt.figure(figsize=(12, 6))
plt.bar(X.columns, importances)
plt.xticks(rotation=90)
plt.title("Hardware Spec Feature Importances")
plt.xlabel("Hardware Features")
plt.ylabel("Importance Score")
plt.tight_layout()
plt.show()

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

lr_model = LogisticRegression(max_iter=1000)
lr_model.fit(X_train_scaled, y_train)

lr_acc = lr_model.score(X_test_scaled, y_test)

print("\n" "============================================================")
print("             BASELINE MODEL COMPARISON")
print("============================================================")
print(f"Logistic Regression Accuracy : {lr_acc:.4f} ({lr_acc * 100:.2f}%)")
print("============================================================" "\n")