# High-Performance Prediction: Mobile Price Classification

## 1. Algorithm Selection and Rationale
For this project, I selected the **Gradient Boosting Classifier**. 

While the initial project brief mentioned Random Forest (a bagging technique), the detailed rubric explicitly required importing a boosting library, tuning the `learning_rate`, and demonstrating how sequential trees fix the errors of previous trees. Random Forest builds independent trees and does not use a learning rate. Therefore, Gradient Boosting is the mathematically correct choice to fulfill the "Weak to Strong" learning requirements of this assignment. 

The goal is to predict the price tier of a flagship mobile phone based on its hardware specifications.

## 2. Data Pulse Check & Visualization
Before training the model, it is critical to inspect the data for missing values, outliers, and class imbalances. 

* **Class Imbalance Check:** As seen in the output below, the dataset is perfectly balanced with exactly 500 instances for each of the four price ranges. No specialized resampling techniques are required.
* **Feature Influence:** The boxplots and pairplots below visualize the relationships between major hardware specs (RAM, Battery Power, Internal Memory) and the target price range.

## 3. Hyperparameter Tuning Documentation
Boosting algorithms build trees sequentially, where each new tree attempts to correct the residual errors made by the previous ones. To optimize this "Weak to Strong" journey, I tuned the following hyperparameters:

* `n_estimators = 150`: Increased the number of sequential trees from the default (100) to give the model more opportunities to learn from previous errors.
* `learning_rate = 0.05`: Decreased the learning rate from the default (0.1). A lower learning rate means each tree contributes less to the final outcome, which prevents the model from over-correcting and overfitting the data.
* `max_depth = 4`: Increased the depth slightly to allow individual trees to capture more complex interactions between hardware components (like RAM and Battery Power combined).

## 4. Feature Importance & Baseline Comparison
One of the primary advantages of Gradient Boosting is its ability to rank which features actually drive the predictions. 

**Key Finding:** The feature importance bar chart below clearly demonstrates that **RAM** is the single most influential factor in determining a mobile phone's price range, massively outweighing features like camera megapixels, core count, or battery size.

**Baseline Comparison:**
To validate the effectiveness of the boosting ensemble, the scaled data was also passed through a standard Logistic Regression model. The output below compares the complex ensemble approach against this simpler linear baseline.