import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

df = pd.read_csv("D:\\Unlox\\June\\Minor Project - 3\\AB_NYC_2019.csv")

print(df.shape)
print(df.columns)
print(df.dtypes)

numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns
categorical_cols = df.select_dtypes(include=['object']).columns

missing_data = df.isnull().sum()
missing_percentage = (missing_data / len(df)) * 100
print(missing_percentage[missing_percentage > 0])

df = df.drop(['last_review'], axis=1)

df['reviews_per_month'] = df['reviews_per_month'].fillna(0)

df = df.drop(['id', 'name', 'host_id', 'host_name'], axis=1)

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
sns.boxplot(x=df['price'])

plt.subplot(1, 2, 2)
sns.boxplot(x=df['minimum_nights'])

plt.show()

price_95 = df['price'].quantile(0.95)
nights_95 = df['minimum_nights'].quantile(0.95)

df = df[(df['price'] <= price_95) & (df['minimum_nights'] <= nights_95)]

df = df.drop(['neighbourhood'], axis=1)

df = pd.get_dummies(df, columns=['neighbourhood_group', 'room_type'], drop_first=True)

X = df.drop(['price'], axis=1)
y = df['price']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)

print(r2)
print(mae)
print(mse)
print(rmse)

plt.figure(figsize=(8, 8))
plt.scatter(y_test, y_pred, alpha=0.3)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
plt.xlabel('Actual Prices')
plt.ylabel('Predicted Prices')
plt.show()

residuals = y_test - y_pred
plt.figure(figsize=(8, 6))
sns.histplot(residuals, kde=True)
plt.xlabel('Errors (Residuals)')
plt.show()