from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from typing import Iterable

from pypdf import PdfReader

SUPPORTED_EXTENSIONS = {"pdf", "txt"}
MAX_FILE_SIZE_MB = 20


@dataclass
class Document:
    text: str
    filename: str
    page: int | None
    source: str


class DocumentLoadError(Exception):
    pass


def clean_text(text: str) -> str:
    lines = [" ".join(line.split()) for line in text.splitlines() if line.strip()]
    return "\n".join(lines).strip()


def validate_file(uploaded_file) -> None:
    extension = uploaded_file.name.rsplit(".", 1)[-1].lower() if "." in uploaded_file.name else ""
    if extension not in SUPPORTED_EXTENSIONS:
        raise DocumentLoadError(f"Unsupported file type: {uploaded_file.name}")

    uploaded_file.seek(0, 2)
    size_mb = uploaded_file.tell() / (1024 * 1024)
    uploaded_file.seek(0)
    if size_mb > MAX_FILE_SIZE_MB:
        raise DocumentLoadError(f"{uploaded_file.name} exceeds the {MAX_FILE_SIZE_MB}MB limit.")


def extract_pdf(uploaded_file) -> list[Document]:
    uploaded_file.seek(0)
    reader = PdfReader(BytesIO(uploaded_file.read()))
    documents = []

    for page_number, page in enumerate(reader.pages, start=1):
        text = clean_text(page.extract_text() or "")
        if text:
            documents.append(
                Document(
                    text=text,
                    filename=uploaded_file.name,
                    page=page_number,
                    source=f"{uploaded_file.name}, page {page_number}",
                )
            )

    return documents


def extract_txt(uploaded_file) -> list[Document]:
    uploaded_file.seek(0)
    raw = uploaded_file.read()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")

    text = clean_text(text)
    if not text:
        return []

    return [Document(text=text, filename=uploaded_file.name, page=None, source=uploaded_file.name)]


def extract_documents(uploaded_files: Iterable) -> list[Document]:
    documents: list[Document] = []

    for uploaded_file in uploaded_files:
        validate_file(uploaded_file)
        extension = uploaded_file.name.rsplit(".", 1)[-1].lower()

        if extension == "pdf":
            documents.extend(extract_pdf(uploaded_file))
        elif extension == "txt":
            documents.extend(extract_txt(uploaded_file))

    if not documents:
        raise DocumentLoadError(
            "No readable text was found. Scanned/image-only PDFs need OCR, which this build does not include."
        )

    return documents
