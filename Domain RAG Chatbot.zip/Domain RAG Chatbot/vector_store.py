from __future__ import annotations

import json
import pickle
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from document_loader import Document

DEFAULT_EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
DEFAULT_CHUNK_SIZE = 800
DEFAULT_CHUNK_OVERLAP = 120
STORE_DIR = Path("vector_store/saved_index")


@dataclass
class Chunk:
    text: str
    source: str
    filename: str
    page: int | None
    chunk_id: int


class VectorStore:
    def __init__(self, model_name: str = DEFAULT_EMBEDDING_MODEL):
        self.model_name = model_name
        self.model = SentenceTransformer(model_name)
        self.index: faiss.Index | None = None
        self.chunks: list[Chunk] = []

    def build(
        self,
        documents: Sequence[Document],
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    ) -> int:
        self.chunks = create_chunks(documents, chunk_size, chunk_overlap)
        embeddings = self._embed([chunk.text for chunk in self.chunks])

        self.index = faiss.IndexFlatIP(embeddings.shape[1])
        self.index.add(embeddings)

        return len(self.chunks)

    def search(self, query: str, top_k: int = 4) -> list[dict]:
        if self.index is None or not self.chunks:
            raise RuntimeError("Vector store is empty. Process documents first.")
        if not query.strip():
            raise ValueError("Question cannot be empty.")

        query_vector = self._embed([query])
        k = min(max(top_k, 1), len(self.chunks))
        scores, indices = self.index.search(query_vector, k)

        results = []
        for score, position in zip(scores[0], indices[0]):
            if position < 0:
                continue
            chunk = self.chunks[int(position)]
            results.append({**asdict(chunk), "score": float(score)})

        return results

    def save(self, directory: Path = STORE_DIR) -> None:
        if self.index is None:
            raise RuntimeError("Nothing to save. Build the index first.")

        directory.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, str(directory / "index.faiss"))

        with open(directory / "chunks.pkl", "wb") as f:
            pickle.dump(self.chunks, f)

        with open(directory / "meta.json", "w") as f:
            json.dump({"model_name": self.model_name, "chunk_count": len(self.chunks)}, f)

    def load(self, directory: Path = STORE_DIR) -> bool:
        index_path = directory / "index.faiss"
        chunks_path = directory / "chunks.pkl"

        if not index_path.exists() or not chunks_path.exists():
            return False

        self.index = faiss.read_index(str(index_path))
        with open(chunks_path, "rb") as f:
            self.chunks = pickle.load(f)

        return True

    def _embed(self, texts: list[str]) -> np.ndarray:
        return self.model.encode(
            texts,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        ).astype("float32")


def split_text(text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be greater than zero.")
    if chunk_overlap < 0 or chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be between 0 and chunk_size.")

    chunks = []
    start = 0

    while start < len(text):
        proposed_end = min(start + chunk_size, len(text))
        end = proposed_end

        if proposed_end < len(text):
            search_start = start + chunk_size // 2
            boundaries = [
                text.rfind("\n", search_start, proposed_end),
                text.rfind(". ", search_start, proposed_end),
                text.rfind(" ", search_start, proposed_end),
            ]
            boundary = max(boundaries)
            if boundary > start:
                end = boundary + 1

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        if end >= len(text):
            break

        start = max(end - chunk_overlap, start + 1)

    return chunks


def create_chunks(documents: Sequence[Document], chunk_size: int, chunk_overlap: int) -> list[Chunk]:
    chunks = []
    chunk_id = 1

    for document in documents:
        for text in split_text(document.text, chunk_size, chunk_overlap):
            chunks.append(
                Chunk(
                    text=text,
                    source=document.source,
                    filename=document.filename,
                    page=document.page,
                    chunk_id=chunk_id,
                )
            )
            chunk_id += 1

    if not chunks:
        raise ValueError("No chunks were created from the uploaded documents.")

    return chunks
