import os
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

from document_loader import DocumentLoadError, extract_documents
from rag_pipeline import DEFAULT_MODEL, DEFAULT_TOP_K, AnswerGenerationError, answer_question
from vector_store import DEFAULT_CHUNK_OVERLAP, DEFAULT_CHUNK_SIZE, VectorStore

load_dotenv(Path(__file__).parent / ".env")

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

st.set_page_config(page_title="Domain-Specific RAG Chatbot", page_icon="📄", layout="wide")

if "vector_store" not in st.session_state:
    st.session_state.vector_store = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "processed_files" not in st.session_state:
    st.session_state.processed_files = []


def process_documents(uploaded_files):
    with st.spinner("Extracting text and building the vector index..."):
        documents = extract_documents(uploaded_files)
        store = VectorStore()
        chunk_count = store.build(documents, chunk_size=DEFAULT_CHUNK_SIZE, chunk_overlap=DEFAULT_CHUNK_OVERLAP)
        store.save()

    st.session_state.vector_store = store
    st.session_state.processed_files = [f.name for f in uploaded_files]
    st.session_state.chat_history = []
    st.success(f"Processed {len(uploaded_files)} file(s) into {chunk_count} chunks.")


with st.sidebar:
    st.header("Documents")

    uploaded_files = st.file_uploader(
        "Upload PDF or TXT files",
        type=["pdf", "txt"],
        accept_multiple_files=True,
    )

    if st.button("Process Documents", type="primary", disabled=not uploaded_files):
        try:
            process_documents(uploaded_files)
        except DocumentLoadError as exc:
            st.error(str(exc))

    if st.session_state.processed_files:
        st.caption("Indexed files:")
        for name in st.session_state.processed_files:
            st.caption(f"• {name}")

    st.divider()
    st.header("Model")

    if GROQ_API_KEY:
        st.caption("Groq API key loaded from .env ✓")
    else:
        st.error("GROQ_API_KEY not found in .env. Add it and restart the app.")

    model_name = st.text_input("Model name", value=DEFAULT_MODEL)
    top_k = st.slider("Chunks to retrieve", 1, 8, DEFAULT_TOP_K)

    st.divider()
    if st.button("Clear Chat"):
        st.session_state.chat_history = []
        st.rerun()

st.title("Domain-Specific RAG Chatbot")
st.caption("Upload documents in the sidebar, click Process Documents, then ask a question below.")

for message in st.session_state.chat_history:
    with st.chat_message(message["role"]):
        st.write(message["content"])
        if message["role"] == "assistant" and message.get("sources"):
            with st.expander("Sources"):
                for source in message["sources"]:
                    st.caption(f"{source['source']} — score {source['score']:.2f}")

question = st.chat_input("Ask a question about your documents...")

if question:
    if st.session_state.vector_store is None:
        st.warning("Upload and process at least one document first.")
    else:
        st.session_state.chat_history.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.write(question)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    result = answer_question(
                        st.session_state.vector_store,
                        question,
                        api_key=GROQ_API_KEY,
                        model_name=model_name,
                        top_k=top_k,
                    )
                    st.write(result["answer"])
                    if result["sources"]:
                        with st.expander("Sources"):
                            for source in result["sources"]:
                                st.caption(f"{source['source']} — score {source['score']:.2f}")

                    st.session_state.chat_history.append(
                        {
                            "role": "assistant",
                            "content": result["answer"],
                            "sources": result["sources"],
                        }
                    )
                except AnswerGenerationError as exc:
                    st.error(str(exc))

st.caption("This assistant can still be wrong. Verify important or high-stakes answers against the source document.")
