# Domain-Specific RAG Chatbot

A Retrieval-Augmented Generation chatbot that answers questions from uploaded PDF/TXT documents (course notes, policies, manuals, legal documents, etc.) and refuses to answer when the information isn't in the documents.

## Architecture

```
Upload PDF/TXT -> document_loader.py -> extract text + page metadata
                -> vector_store.py    -> chunk, embed (MiniLM), store in FAISS
User question   -> vector_store.py    -> embed question, retrieve top-k chunks
                -> rag_pipeline.py    -> send context + question to Groq LLM
                -> prompt.py          -> system prompt enforces grounded answers
                -> app.py             -> Streamlit chat UI with source display
```

## Files

```
domain_rag_chatbot/
├── app.py                 Streamlit UI (upload, chat, sources)
├── document_loader.py     PDF/TXT extraction with page metadata
├── vector_store.py        Chunking, embeddings, FAISS index, save/load
├── rag_pipeline.py        Retrieval + LLM answer generation
├── prompt.py               System prompt / guardrail
├── requirements.txt
├── .env.example
├── .gitignore
├── documents/sample.txt   Sample document for testing
├── vector_store/          Saved FAISS index (created after processing)
└── tests/test_questions.csv
```

## Setup

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Get a free Groq API key at https://console.groq.com/keys, then:

```powershell
copy .env.example .env
```

Edit `.env`:

```
GROQ_API_KEY=your_real_key_here
```

## Run

```powershell
streamlit run app.py
```

Open `http://localhost:8501`, upload a PDF or TXT file in the sidebar, click **Process Documents**, then ask questions in the chat box.

## How it works

1. **Document Upload** — sidebar file uploader accepts multiple PDF/TXT files, validated for type and size.
2. **Text Extraction** — `pypdf` reads each page; page number is kept as metadata so answers can cite `filename, page N`.
3. **Chunking** — text is split into ~800-character chunks with 120-character overlap, breaking on sentence/paragraph boundaries where possible.
4. **Embeddings** — `sentence-transformers/all-MiniLM-L6-v2` converts each chunk to a vector.
5. **Vector Store** — vectors are stored in a FAISS `IndexFlatIP` (cosine similarity via normalized embeddings) and saved to `vector_store/saved_index/`.
6. **Retrieval** — the question is embedded and the top-k most similar chunks are retrieved.
7. **Answer Generation** — retrieved chunks + question are sent to a Groq LLM with a strict system prompt: answer only from context, or return a fixed fallback message.
8. **UI** — chat history, per-answer source expander, and a Clear Chat button.

## Testing

`tests/test_questions.csv` has 15 questions split between answerable (from `documents/sample.txt`) and "not available" cases, to check retrieval accuracy and refusal behavior. Fill in the `Retrieved Source` / `Correct?` columns while testing manually, or extend `rag_pipeline.answer_question` into a script that runs the CSV automatically.

## Responsible AI notes

- API keys are read from `.env` / the sidebar field, never hardcoded.
- The system prompt tells the model to treat retrieved text as data, not instructions — this blocks basic prompt-injection attempts hidden inside uploaded documents.
- The UI shows a persistent reminder to verify high-stakes answers.
- `vector_store/saved_index/` and `.env` are git-ignored so keys and generated indexes aren't committed.

## Known limitations

- Scanned/image-only PDFs are not supported (no OCR in this build — noted in `document_loader.py` as an extension point).
- Answer quality depends on chunk boundaries; very short or table-heavy documents may retrieve less precisely.