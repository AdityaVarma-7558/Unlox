from __future__ import annotations

from groq import Groq

from prompt import FALLBACK_ANSWER, SYSTEM_PROMPT, build_user_message
from vector_store import VectorStore

DEFAULT_MODEL = "llama-3.3-70b-versatile"
DEFAULT_TOP_K = 4


class AnswerGenerationError(Exception):
    pass


def retrieve(vector_store: VectorStore, question: str, top_k: int = DEFAULT_TOP_K) -> list[dict]:
    return vector_store.search(question, top_k=top_k)


def generate_answer(
    question: str,
    retrieved_chunks: list[dict],
    api_key: str,
    model_name: str = DEFAULT_MODEL,
) -> str:
    if not api_key:
        raise AnswerGenerationError("Missing Groq API key. Add it in the sidebar or in .env.")

    if not retrieved_chunks:
        return FALLBACK_ANSWER

    client = Groq(api_key=api_key)

    try:
        completion = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": build_user_message(question, retrieved_chunks)},
            ],
            temperature=0.1,
            max_completion_tokens=700,
        )
    except Exception as exc:
        raise AnswerGenerationError(f"The language model request failed: {exc}") from exc

    answer = completion.choices[0].message.content
    if not answer:
        raise AnswerGenerationError("The model returned an empty answer.")

    return answer.strip()


def answer_question(
    vector_store: VectorStore,
    question: str,
    api_key: str,
    model_name: str = DEFAULT_MODEL,
    top_k: int = DEFAULT_TOP_K,
) -> dict:
    retrieved_chunks = retrieve(vector_store, question, top_k=top_k)
    answer = generate_answer(question, retrieved_chunks, api_key, model_name)

    return {
        "answer": answer,
        "sources": retrieved_chunks,
        "grounded": answer.strip() != FALLBACK_ANSWER,
    }
