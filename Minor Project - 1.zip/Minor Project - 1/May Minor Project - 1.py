"""
### 1. Environment Setup & Data Loading
Objective: I set up my working environment by importing the necessary analytical libraries and loading the raw dataset. I used pandas for data manipulation, numpy for numerical operations, and matplotlib alongside seaborn to generate my visualizations.
"""
# Import required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset into a pandas DataFrame to begin manipulation
df = pd.read_csv("D:\\Unlox\\May\\Minor Project - 1\\imdb_top_1000.csv")

# Display the first 5 rows to visually verify the data loaded correctly
print(df.head())
print("\n")

"""
### 2. Structural Inspection
Objective: I performed an initial audit to understand the dimensions and composition of the dataset. This step helped me identify which columns contain numerical versus categorical data and allowed me to spot early anomalies like incorrect data types.
"""
# Check data types, non-null counts, and memory usage. 
df.info()
print("\n")

# Generate summary statistics for numerical columns
print(df.describe())
print("\n")

# Output the exact dimensions (rows, columns)
print(f"Shape: {df.shape}")
print("\n")

"""
### 3. Data Cleaning (The Preprocessing Phase)
Objective: I cleansed the dataset to ensure my analysis would be accurate. First, I dropped rows with missing values in critical columns to prevent them from skewing the results. Next, I removed identical rows to avoid double-counting. Finally, I corrected data types by converting features like 'Gross' and 'Runtime' into pure numerical formats so I could perform mathematical operations on them.
"""
# Drop rows where 'Certificate', 'Meta_score', or 'Gross' are missing.
df = df.dropna(subset=['Certificate', 'Meta_score', 'Gross'])

# Remove any identified duplicates to ensure data integrity.
df = df.drop_duplicates()

# Clean the 'Gross' column: remove commas from the strings, then cast to float.
df['Gross'] = df['Gross'].str.replace(',', '').astype(float)

# Clean the 'Runtime' column: remove the text " min", then cast to integer.
df['Runtime'] = df['Runtime'].str.replace(' min', '').astype(int)

"""
### 4. Univariate Analysis
Objective: I analyzed individual features in isolation to understand their distributions. I used a histogram for 'Runtime' to see where movie lengths typically cluster and to check for outliers. I also created a count plot for 'Certificate' to observe the frequency of different age ratings in the dataset.
"""
# --- Numerical Univariate Analysis ---
plt.figure(figsize=(10, 6))
sns.histplot(df['Runtime'], kde=True)
plt.title('Distribution of Movie Runtimes')
plt.xlabel('Runtime (minutes)')
plt.ylabel('Frequency')
plt.show()

# --- Categorical Univariate Analysis ---
plt.figure(figsize=(12, 6))
sns.countplot(data=df, x='Certificate', order=df['Certificate'].value_counts().index, hue='Certificate', legend=False)
plt.title('Frequency of Movie Certificates')
plt.xlabel('Certificate Type')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.show()

"""
### 5. Bivariate & Multivariate Analysis
Objective: I explored relationships between multiple variables. I generated a correlation matrix to quantify the linear relationships between all numerical features. Then, I used a scatter plot to visualize how IMDb Rating relates to Gross earnings, and a grouped box plot to compare the spread of ratings across different certificate categories.
"""
# --- Correlation Analysis ---
numerical_cols = df.select_dtypes(include=[np.number])
plt.figure(figsize=(8, 6))
sns.heatmap(numerical_cols.corr(), annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix of Numerical Features')
plt.show()

# --- Bivariate Scatter Plot ---
plt.figure(figsize=(10, 6))
sns.scatterplot(data=df, x='IMDB_Rating', y='Gross', alpha=0.6)
plt.title('IMDb Rating vs. Gross Earnings')
plt.xlabel('IMDb Rating')
plt.ylabel('Gross Earnings ($)')
plt.show()

# --- Multivariate Box Plot ---
plt.figure(figsize=(12, 6))
sns.boxplot(data=df, x='Certificate', y='IMDB_Rating', hue='Certificate', legend=False)
plt.title('IMDb Ratings Across Different Certificates')
plt.xlabel('Certificate')
plt.ylabel('IMDb Rating')
plt.xticks(rotation=45)
plt.show()