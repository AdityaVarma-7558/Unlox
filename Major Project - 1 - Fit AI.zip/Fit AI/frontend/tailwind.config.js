/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],

  theme: {
    extend: {
      colors: {
        primary: '#3B82F6',
        trainer: '#22C55E',
        dietician: '#A855F7',
        buddy: '#F59E0B',
        habit: '#06B6D4',
        recommender: '#F97316',
        performance: '#F43F5E',
        gyms: '#10B981',

        dark: '#000000',
        card: 'rgba(255,255,255,0.04)',
        border: 'rgba(255,255,255,0.08)',

        glass: 'rgba(255,255,255,0.05)',
        surface: '#0A0A0A',
        muted: '#141414',
      },

      fontFamily: {
        display: ['Poppins', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
      },

      backdropBlur: {
        xs: '2px',
      },

      borderRadius: {
        xl2: '22px',
      },

      boxShadow: {
        glowBlue: '0 0 25px rgba(59,130,246,.45)',
        glowGreen: '0 0 25px rgba(34,197,94,.45)',
        glowPurple: '0 0 25px rgba(168,85,247,.45)',
        glowOrange: '0 0 25px rgba(249,115,22,.45)',
        glowRose: '0 0 25px rgba(244,63,94,.45)',
        glowCyan: '0 0 25px rgba(6,182,212,.45)',
      },

      animation: {
        float: 'float 5s ease-in-out infinite',
        pulseSlow: 'pulse 3s infinite',
        fadeUp: 'fadeUp .5s ease',
      },

      keyframes: {
        float: {
          '0%,100%': {
            transform: 'translateY(0px)',
          },
          '50%': {
            transform: 'translateY(-10px)',
          },
        },

        fadeUp: {
          from: {
            opacity: 0,
            transform: 'translateY(25px)',
          },
          to: {
            opacity: 1,
            transform: 'translateY(0px)',
          },
        },
      },
    },
  },

  plugins: [],
}
