# FitAI Frontend

React + Vite + TypeScript dark-themed frontend for FitAI.

## Setup

```bash
cd frontend
npm install
npm run dev
```

Runs on `http://localhost:5173` and expects the backend at `http://localhost:5000`.

> **Note:** `node_modules` isn't included in this delivery (it's ~250MB and machine-specific).
> Run `npm install` once after unzipping — it also picks up the dependency fixes below.