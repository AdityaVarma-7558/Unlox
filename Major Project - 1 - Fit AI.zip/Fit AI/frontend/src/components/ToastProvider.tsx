import { Toaster } from "react-hot-toast";

export default function ToastProvider(){

return(

<Toaster

position="top-right"

toastOptions={{

style:{

background:"#161616",

color:"white",

borderRadius:"16px"

}

}}

/>

)

}