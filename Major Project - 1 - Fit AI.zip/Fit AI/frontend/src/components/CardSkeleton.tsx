import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

export default function CardSkeleton(){

return(

<div

className="

rounded-3xl

bg-white/5

p-6

"

>

<Skeleton

height={30}

/>

<Skeleton

count={4}

/>

</div>

)

}