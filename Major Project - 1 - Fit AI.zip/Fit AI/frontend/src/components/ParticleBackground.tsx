import { useCallback } from "react";
import Particles from "react-tsparticles";
import { loadSlim } from "tsparticles-slim";
import type { Engine } from "tsparticles-engine";

export default function ParticleBackground() {
  const particlesInit = useCallback(async (engine: Engine) => {
    await loadSlim(engine);
  }, []);

  return (
    <Particles
      id="particles"
      init={particlesInit}
      options={{
        fullScreen: {
          enable: true,
          zIndex: -10,
        },
        background: {
          color: {
            value: "#000000",
          },
        },
        particles: {
          number: {
            value: 55,
          },
          color: {
            value: "#3B82F6",
          },
          links: {
            enable: true,
            color: "#3B82F6",
            opacity: 0.2,
          },
          move: {
            enable: true,
            speed: 0.8,
          },
          opacity: {
            value: 0.3,
          },
          size: {
            value: 2,
          },
        },
      }}
    />
  );
}
