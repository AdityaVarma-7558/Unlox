import { motion } from "framer-motion";

interface Props{

children:any;

onClick?:()=>void;

color?:string;

type?:"button"|"submit";

}

export default function GlowButton({

children,

onClick,

color="#3B82F6",

type="button"

}:Props){

return(

<motion.button

whileHover={{scale:1.05}}

whileTap={{scale:0.96}}

type={type}

onClick={onClick}

style={{

background:color,

boxShadow:`0px 0px 25px ${color}`

}}

className="

px-5

py-3

rounded-xl

font-semibold

text-white

transition-all

"

>

{children}

</motion.button>

)

}