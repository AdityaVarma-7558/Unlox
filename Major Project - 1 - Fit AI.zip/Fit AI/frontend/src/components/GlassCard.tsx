import { motion } from "framer-motion";

interface Props{
    children:any;
    className?:string;
}

export default function GlassCard({children,className=""}:Props){

    return(

        <motion.div

        initial={{opacity:0,y:20}}

        animate={{opacity:1,y:0}}

        transition={{duration:0.5}}

        className={`

        rounded-3xl

        border

        border-white/10

        bg-white/5

        backdrop-blur-xl

        shadow-2xl

        p-6

        ${className}

        `}

        >

        {children}

        </motion.div>

    )

}