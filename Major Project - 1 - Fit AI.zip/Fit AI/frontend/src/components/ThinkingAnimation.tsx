import { motion } from "framer-motion";

export default function ThinkingAnimation(){

return(

<div

className="

flex

justify-center

items-center

py-10

"

>

<motion.div

animate={{

scale:[1,1.5,1],

opacity:[0.4,1,0.4]

}}

transition={{

repeat:Infinity,

duration:1

}}

className="

w-5

h-5

rounded-full

bg-primary

"

/>

</div>

)

}