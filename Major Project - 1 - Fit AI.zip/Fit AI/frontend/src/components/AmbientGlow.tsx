export default function AmbientGlow() {

    return (

        <>

            <div

                className="

                fixed

                top-[-250px]

                left-[-250px]

                w-[600px]

                h-[600px]

                rounded-full

                bg-blue-600/20

                blur-[180px]

                -z-10

                "

            />

            <div

                className="

                fixed

                bottom-[-300px]

                right-[-300px]

                w-[650px]

                h-[650px]

                rounded-full

                bg-violet-600/20

                blur-[220px]

                -z-10

                "

            />

        </>

    )

}