import { TypeAnimation } from "react-type-animation";

interface Props{

text:string;

}

export default function TypingText({

text

}:Props){

return(

<TypeAnimation

sequence={[

text

]}

speed={75}

cursor={true}

repeat={0}

/>

)

}