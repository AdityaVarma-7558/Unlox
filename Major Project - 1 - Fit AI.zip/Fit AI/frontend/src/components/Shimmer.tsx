export default function Shimmer(){

return(

<div

className="

relative

overflow-hidden

rounded-xl

bg-white/10

h-32

"

>

<div

className="

absolute

inset-0

animate-pulse

bg-gradient-to-r

from-transparent

via-white/20

to-transparent

"

/>

</div>

)

}