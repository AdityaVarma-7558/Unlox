import { NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import {
  LayoutDashboard, Dumbbell, Salad, MessageCircle,
  Activity, Map, MapPin, TrendingUp, LogOut, Zap
} from 'lucide-react'

const links = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/trainer', icon: Dumbbell, label: 'AI Trainer' },
  { to: '/dietician', icon: Salad, label: 'Dietician' },
  { to: '/buddy', icon: MessageCircle, label: 'Gym Buddy' },
  { to: '/habit', icon: Activity, label: 'Habit Tracker' },
  { to: '/recommender', icon: Map, label: 'Recommender' },
  { to: '/nearby-gyms', icon: MapPin, label: 'Nearby Gyms' },
  { to: '/performance', icon: TrendingUp, label: 'Performance' },
]

export default function Sidebar() {
  const { user, logout } = useAuth()

  return (
    <aside className="w-64 min-h-screen bg-card border-r border-gray-800 flex flex-col">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <Zap className="text-primary" size={24} />
          <span className="text-xl font-display font-bold text-white">FitAI</span>
        </div>
        <p className="text-xs text-gray-500 mt-1">AI Fitness Ecosystem</p>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {links.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                isActive
                  ? 'bg-primary/10 text-primary font-medium'
                  : 'text-gray-400 hover:text-white hover:bg-muted'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.name}</p>
            <p className="text-xs text-gray-500 truncate">{user?.fitness_goal || 'No goal set'}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="flex items-center gap-2 text-xs text-gray-500 hover:text-red-400 transition-colors w-full"
        >
          <LogOut size={14} />
          Sign out
        </button>
      </div>
    </aside>
  )
}
