export const moduleColors = {
  dashboard: "#3B82F6",
  trainer: "#22C55E",
  dietician: "#A855F7",
  buddy: "#F59E0B",
  habit: "#06B6D4",
  recommender: "#F97316",
  performance: "#F43F5E",
  iot: "#10B981"
};

export const glass = {
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.08)",
  backdropFilter: "blur(20px)"
};