import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { AuthProvider, useAuth } from './context/AuthContext'

import Sidebar from './components/Sidebar'
import ParticleBackground from './components/ParticleBackground'
import AmbientGlow from './components/AmbientGlow'

import AuthPage from './pages/AuthPage'
import Dashboard from './pages/Dashboard'
import TrainerPage from './pages/TrainerPage'
import DieticianPage from './pages/DieticianPage'
import BuddyPage from './pages/BuddyPage'
import HabitPage from './pages/HabitPage'
import RecommenderPage from './pages/RecommenderPage'
import NearbyGymsPage from './pages/NearbyGymsPage'
import PerformancePage from './pages/PerformancePage'

function AnimatedRoutes() {
  const location = useLocation()

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />

        <Route path="/dashboard" element={<PageTransition><Dashboard /></PageTransition>} />
        <Route path="/trainer" element={<PageTransition><TrainerPage /></PageTransition>} />
        <Route path="/dietician" element={<PageTransition><DieticianPage /></PageTransition>} />
        <Route path="/buddy" element={<PageTransition><BuddyPage /></PageTransition>} />
        <Route path="/habit" element={<PageTransition><HabitPage /></PageTransition>} />
        <Route path="/recommender" element={<PageTransition><RecommenderPage /></PageTransition>} />
        <Route path="/nearby-gyms" element={<PageTransition><NearbyGymsPage /></PageTransition>} />
        <Route path="/performance" element={<PageTransition><PerformancePage /></PageTransition>} />
      </Routes>
    </AnimatePresence>
  )
}

function PageTransition({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
    >
      {children}
    </motion.div>
  )
}

function AppLayout() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-dark flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    )
  }

  if (!user) {
    return <AuthPage />
  }

  return (
    <>
      {/* Premium Background */}
      <ParticleBackground />
      <AmbientGlow />

      <div className="flex min-h-screen bg-dark text-white relative overflow-hidden">
        <Sidebar />

        <main className="flex-1 overflow-auto relative z-10">
          <AnimatedRoutes />
        </main>
      </div>
    </>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppLayout />
      </AuthProvider>
    </BrowserRouter>
  )
}
