import { useState } from 'react'
import { MapPin, Navigation, ExternalLink, RefreshCw, Dumbbell } from 'lucide-react'

interface Gym {
  id: number
  name: string
  lat: number
  lon: number
  address?: string
  distanceKm: number
}

type Status = 'idle' | 'locating' | 'loading' | 'done' | 'error'

const OVERPASS_URL = 'https://overpass-api.de/api/interpreter'
const SEARCH_RADIUS_METERS = 10000

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2
  return R * 2 * Math.asin(Math.sqrt(a))
}

function formatAddress(tags: Record<string, string>) {
  const parts = [tags['addr:housenumber'], tags['addr:street'], tags['addr:suburb'] || tags['addr:city']]
    .filter(Boolean)
  return parts.length ? parts.join(', ') : undefined
}

export default function NearbyGymsPage() {
  const [status, setStatus] = useState<Status>('idle')
  const [gyms, setGyms] = useState<Gym[]>([])
  const [error, setError] = useState('')
  const [origin, setOrigin] = useState<{ lat: number; lon: number } | null>(null)

  const findGyms = () => {
    setStatus('locating')
    setError('')
    setGyms([])

    if (!('geolocation' in navigator)) {
      setStatus('error')
      setError('Your browser does not support location access.')
      return
    }

    navigator.geolocation.getCurrentPosition(
      async ({ coords }) => {
        const { latitude: lat, longitude: lon } = coords
        setOrigin({ lat, lon })
        setStatus('loading')

        const query = `
          [out:json][timeout:25];
          (
            node["leisure"="fitness_centre"](around:${SEARCH_RADIUS_METERS},${lat},${lon});
            way["leisure"="fitness_centre"](around:${SEARCH_RADIUS_METERS},${lat},${lon});
            node["sport"="fitness"](around:${SEARCH_RADIUS_METERS},${lat},${lon});
            node["leisure"="sports_centre"](around:${SEARCH_RADIUS_METERS},${lat},${lon});
            node["name"~"gym|fitness",i](around:${SEARCH_RADIUS_METERS},${lat},${lon});
          );
          out center;
        `

        try {
          const res = await fetch(OVERPASS_URL, {
            method: 'POST',
            body: 'data=' + encodeURIComponent(query),
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          })
          if (!res.ok) throw new Error('Search service unavailable')
          const data = await res.json()

          const seen = new Set<number>()
          const results: Gym[] = (data.elements || [])
            .map((el: any) => {
              const elLat = el.lat ?? el.center?.lat
              const elLon = el.lon ?? el.center?.lon
              if (elLat == null || elLon == null) return null
              if (seen.has(el.id)) return null
              seen.add(el.id)
              return {
                id: el.id,
                name: el.tags?.name || 'Unnamed gym',
                lat: elLat,
                lon: elLon,
                address: formatAddress(el.tags || {}),
                distanceKm: haversineKm(lat, lon, elLat, elLon),
              }
            })
            .filter(Boolean)
            .sort((a: Gym, b: Gym) => a.distanceKm - b.distanceKm)

          setGyms(results)
          setStatus('done')
        } catch {
          setStatus('error')
          setError('Could not fetch nearby gyms. Please try again.')
        }
      },
      (geoError) => {
        setStatus('error')
        setError(
          geoError.code === geoError.PERMISSION_DENIED
            ? 'Location access was denied. Please allow location permissions and try again.'
            : 'Could not determine your location. Please try again.'
        )
      },
      { enableHighAccuracy: true, timeout: 10000 }
    )
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Nearby Gyms</h1>
          <p className="text-gray-400 mt-1">Real gyms and fitness centres near your current location</p>
        </div>
        <button
          onClick={findGyms}
          disabled={status === 'locating' || status === 'loading'}
          className="flex items-center gap-2 bg-primary text-dark font-semibold px-4 py-2.5 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50"
        >
          {status === 'locating' || status === 'loading' ? (
            <RefreshCw size={16} className="animate-spin" />
          ) : (
            <Navigation size={16} />
          )}
          {status === 'locating' ? 'Locating...' : status === 'loading' ? 'Searching...' : 'Find gyms near me'}
        </button>
      </div>

      {status === 'idle' && (
        <div className="glass rounded-xl p-12 text-center">
          <MapPin size={48} className="text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Tap "Find gyms near me" to see real gyms close to you.</p>
          <p className="text-gray-600 text-sm mt-2">Your browser will ask for location permission — nothing is stored or shared.</p>
        </div>
      )}

      {status === 'error' && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-sm px-4 py-3 rounded-xl">
          {error}
        </div>
      )}

      {status === 'done' && gyms.length === 0 && origin && (
        <div className="glass rounded-xl p-12 text-center">
          <Dumbbell size={48} className="text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">No gyms found within {SEARCH_RADIUS_METERS / 1000}km on OpenStreetMap.</p>
          <p className="text-gray-600 text-sm mt-2 mb-5 max-w-md mx-auto">
            OpenStreetMap is community-mapped, so smaller local gyms are sometimes missing from it even
            when they exist. Try Google Maps instead — it has much denser business listings.
          </p>
          <a
            href={`https://www.google.com/maps/search/gyms+near+me/@${origin.lat},${origin.lon},14z`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-primary text-dark font-semibold px-4 py-2.5 rounded-lg text-sm hover:bg-primary/90 transition-colors"
          >
            Search on Google Maps <ExternalLink size={14} />
          </a>
        </div>
      )}

      {gyms.length > 0 && (
        <div className="grid grid-cols-2 gap-4">
          {gyms.map(gym => (
            <div key={gym.id} className="glass rounded-xl p-5 flex items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="text-white font-medium truncate">{gym.name}</p>
                {gym.address && <p className="text-gray-500 text-sm mt-1">{gym.address}</p>}
                <p className="text-primary text-sm mt-2">{gym.distanceKm.toFixed(1)} km away</p>
              </div>
              <a
                href={`https://www.openstreetmap.org/?mlat=${gym.lat}&mlon=${gym.lon}#map=17/${gym.lat}/${gym.lon}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-shrink-0 flex items-center gap-1.5 text-xs text-gray-400 hover:text-primary transition-colors"
              >
                Map <ExternalLink size={12} />
              </a>
            </div>
          ))}
        </div>
      )}

      {origin && gyms.length > 0 && (
        <p className="text-gray-600 text-xs mt-6">
          Results from OpenStreetMap, within {SEARCH_RADIUS_METERS / 1000}km of your current location.
        </p>
      )}
    </div>
  )
}