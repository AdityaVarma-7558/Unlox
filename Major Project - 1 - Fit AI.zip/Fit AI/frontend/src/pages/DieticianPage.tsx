import { useState } from 'react'
import { apiFetch } from '../api/client'
import { Salad, ShoppingCart, Search } from 'lucide-react'

type Tab = 'plan' | 'calories' | 'grocery'

export default function DieticianPage() {
  const [tab, setTab] = useState<Tab>('plan')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')

  const [planForm, setPlanForm] = useState({ fitness_goal: '', dietary_preference: '', allergies: '' })
  const [foodInput, setFoodInput] = useState('')
  const [groceryForm, setGroceryForm] = useState({ budget: 'moderate' })

  const getDietPlan = async () => {
    setLoading(true); setResult('')
    try {
      const d = await apiFetch('/dietician/plan', { method: 'POST', body: JSON.stringify(planForm) })
      setResult(d.plan + (d.bmi ? `\n\n**Your BMI: ${d.bmi}**` : ''))
    } catch (e: unknown) { setResult('Error: ' + (e instanceof Error ? e.message : String(e))) }
    finally { setLoading(false) }
  }

  const analyzeCalories = async () => {
    if (!foodInput.trim()) return
    setLoading(true); setResult('')
    try {
      const d = await apiFetch('/dietician/calories', { method: 'POST', body: JSON.stringify({ food: foodInput }) })
      setResult(d.analysis)
    } catch (e: unknown) { setResult('Error: ' + (e instanceof Error ? e.message : String(e))) }
    finally { setLoading(false) }
  }

  const getGrocery = async () => {
    setLoading(true); setResult('')
    try {
      const d = await apiFetch('/dietician/grocery', { method: 'POST', body: JSON.stringify(groceryForm) })
      setResult(d.grocery_list)
    } catch (e: unknown) { setResult('Error: ' + (e instanceof Error ? e.message : String(e))) }
    finally { setLoading(false) }
  }

  return (
    <div className="p-8">
      <h1 className="text-3xl font-display font-bold text-white mb-2">AI Dietician & Calorie Coach</h1>
      <p className="text-gray-400 mb-8">Personalized diet plans, nutrition analysis, and grocery lists</p>

      <div className="flex gap-2 mb-6 p-1 bg-muted rounded-lg w-fit">
        {(['plan', 'calories', 'grocery'] as Tab[]).map(t => (
          <button key={t} onClick={() => { setTab(t); setResult('') }}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all capitalize ${tab === t ? 'bg-primary text-dark' : 'text-gray-400 hover:text-white'}`}>
            {t === 'plan' ? '7-Day Plan' : t === 'calories' ? 'Calorie Check' : 'Grocery List'}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="glass rounded-xl p-6">
          {tab === 'plan' && (
            <div className="space-y-4">
              <h3 className="font-display font-semibold text-white flex items-center gap-2"><Salad size={16} className="text-primary" /> Generate Diet Plan</h3>
              <select value={planForm.fitness_goal} onChange={e => setPlanForm(f => ({ ...f, fitness_goal: e.target.value }))}
                className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary">
                <option value="">Your fitness goal</option>
                {['Weight loss', 'Muscle gain', 'Endurance', 'General fitness'].map(g => <option key={g} value={g}>{g}</option>)}
              </select>
              <select value={planForm.dietary_preference} onChange={e => setPlanForm(f => ({ ...f, dietary_preference: e.target.value }))}
                className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary">
                <option value="">Dietary preference</option>
                {['Vegetarian', 'Vegan', 'Non-vegetarian', 'Keto', 'Gluten-free'].map(d => <option key={d} value={d}>{d}</option>)}
              </select>
              <input placeholder="Allergies (optional)" value={planForm.allergies}
                onChange={e => setPlanForm(f => ({ ...f, allergies: e.target.value }))}
                className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
              <button onClick={getDietPlan} disabled={loading}
                className="w-full bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50">
                {loading ? 'Generating...' : 'Generate Plan'}
              </button>
            </div>
          )}

          {tab === 'calories' && (
            <div className="space-y-4">
              <h3 className="font-display font-semibold text-white flex items-center gap-2"><Search size={16} className="text-primary" /> Analyze Food</h3>
              <input placeholder="e.g. 2 boiled eggs with toast" value={foodInput} onChange={e => setFoodInput(e.target.value)}
                className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
              <button onClick={analyzeCalories} disabled={loading || !foodInput.trim()}
                className="w-full bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50">
                {loading ? 'Analyzing...' : 'Analyze Calories'}
              </button>
            </div>
          )}

          {tab === 'grocery' && (
            <div className="space-y-4">
              <h3 className="font-display font-semibold text-white flex items-center gap-2"><ShoppingCart size={16} className="text-primary" /> Grocery List</h3>
              <select value={groceryForm.budget} onChange={e => setGroceryForm({ budget: e.target.value })}
                className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary">
                {['budget', 'moderate', 'premium'].map(b => <option key={b} value={b} className="capitalize">{b.charAt(0).toUpperCase() + b.slice(1)}</option>)}
              </select>
              <button onClick={getGrocery} disabled={loading}
                className="w-full bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50">
                {loading ? 'Generating...' : 'Generate List'}
              </button>
            </div>
          )}
        </div>

        <div className="col-span-2 glass rounded-xl p-6 overflow-auto max-h-[70vh]">
          {loading && <div className="flex items-center gap-3 text-gray-400"><div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" /> Generating with your local Gemma-3 model...</div>}
          {result && (
            <pre className="text-sm text-gray-300 whitespace-pre-wrap font-body leading-relaxed">{result}</pre>
          )}
          {!result && !loading && (
            <div className="flex items-center justify-center h-full text-gray-600">
              <p>Your AI-generated content will appear here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
