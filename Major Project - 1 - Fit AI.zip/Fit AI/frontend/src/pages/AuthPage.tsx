import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { Zap } from 'lucide-react'

export default function AuthPage() {
  const { login, register } = useAuth()
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const [form, setForm] = useState({
    name: '', email: '', password: '',
    age: '', weight: '', height: '',
    fitness_goal: '', dietary_preference: ''
  })

  const handle = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      if (mode === 'login') {
        await login(form.email, form.password)
      } else {
        await register({
          ...form,
          age: Number(form.age),
          weight: Number(form.weight),
          height: Number(form.height),
        })
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <Zap className="text-primary" size={32} />
            <span className="text-3xl font-display font-bold">FitAI</span>
          </div>
          <p className="text-gray-400">Your AI-powered fitness ecosystem</p>
        </div>

        <div className="glass rounded-2xl p-8">
          <div className="flex gap-2 mb-6 p-1 bg-muted rounded-lg">
            {(['login', 'register'] as const).map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-all capitalize ${
                  mode === m ? 'bg-primary text-dark' : 'text-gray-400 hover:text-white'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-sm px-4 py-3 rounded-lg mb-4">
              {error}
            </div>
          )}

          <form onSubmit={submit} className="space-y-4">
            {mode === 'register' && (
              <input
                name="name" placeholder="Full name" value={form.name} onChange={handle} required
                className="w-full bg-muted border border-gray-700 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary"
              />
            )}
            <input
              name="email" type="email" placeholder="Email" value={form.email} onChange={handle} required
              className="w-full bg-muted border border-gray-700 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary"
            />
            <input
              name="password" type="password" placeholder="Password" value={form.password} onChange={handle} required
              className="w-full bg-muted border border-gray-700 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary"
            />

            {mode === 'register' && (
              <>
                <div className="grid grid-cols-3 gap-3">
                  {['age', 'weight', 'height'].map(f => (
                    <input
                      key={f} name={f} type="number" placeholder={f.charAt(0).toUpperCase() + f.slice(1)}
                      value={form[f as keyof typeof form]} onChange={handle}
                      className="w-full bg-muted border border-gray-700 rounded-lg px-3 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary"
                    />
                  ))}
                </div>
                <select
                  name="fitness_goal" value={form.fitness_goal} onChange={handle}
                  className="w-full bg-muted border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary"
                >
                  <option value="">Fitness goal (optional)</option>
                  {['Weight loss', 'Muscle gain', 'Endurance', 'Flexibility', 'General fitness'].map(g => (
                    <option key={g} value={g.toLowerCase()}>{g}</option>
                  ))}
                </select>
                <select
                  name="dietary_preference" value={form.dietary_preference} onChange={handle}
                  className="w-full bg-muted border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary"
                >
                  <option value="">Dietary preference (optional)</option>
                  {['Vegetarian', 'Vegan', 'Non-vegetarian', 'Keto', 'Gluten-free'].map(d => (
                    <option key={d} value={d.toLowerCase()}>{d}</option>
                  ))}
                </select>
              </>
            )}

            <button
              type="submit" disabled={loading}
              className="w-full bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {loading ? 'Please wait...' : mode === 'login' ? 'Sign in' : 'Create account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
