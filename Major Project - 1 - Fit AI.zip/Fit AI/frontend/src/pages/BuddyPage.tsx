import { useState, useEffect, useRef } from 'react'
import { apiFetch } from '../api/client'
import { Send, Trash2, Bot, Mic, MicOff, Volume2, VolumeX } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast'

interface Message { role: string; content: string; created_at?: string }

type SpeechRecognitionLike = {
  continuous: boolean
  interimResults: boolean
  lang: string
  start: () => void
  stop: () => void
  onresult: ((event: any) => void) | null
  onerror: ((event: any) => void) | null
  onend: (() => void) | null
}

function getSpeechRecognition(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === 'undefined') return null
  const w = window as any
  return w.SpeechRecognition || w.webkitSpeechRecognition || null
}

export default function BuddyPage() {
  const { user } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [listening, setListening] = useState(false)
  const [voiceReplyEnabled, setVoiceReplyEnabled] = useState(false)
  const [voiceSupported, setVoiceSupported] = useState(true)
  const bottomRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null)

  useEffect(() => {
    apiFetch('/buddy/history').then(d => setMessages(d.messages)).catch(() => {})
    setVoiceSupported(!!getSpeechRecognition() && 'speechSynthesis' in window)
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const speak = (text: string) => {
    if (!voiceReplyEnabled || !('speechSynthesis' in window)) return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 1.02
    utterance.pitch = 1.05
    window.speechSynthesis.speak(utterance)
  }

  const send = async (overrideText?: string) => {
    const text = overrideText ?? input
    if (!text.trim() || loading) return
    const userMsg: Message = { role: 'user', content: text }
    setMessages(m => [...m, userMsg])
    setInput('')
    setLoading(true)
    try {
      const d = await apiFetch('/buddy/chat', { method: 'POST', body: JSON.stringify({ message: text }) })
      setMessages(m => [...m, { role: 'assistant', content: d.reply }])
      speak(d.reply)
    } catch {
      setMessages(m => [...m, { role: 'assistant', content: 'Sorry, something went wrong. Try again!' }])
    } finally {
      setLoading(false)
    }
  }

  const clearChat = async () => {
    await apiFetch('/buddy/clear', { method: 'DELETE' }).catch(() => {})
    setMessages([])
  }

  const toggleListening = () => {
    const SpeechRecognitionCtor = getSpeechRecognition()
    if (!SpeechRecognitionCtor) {
      toast.error('Voice input is not supported in this browser. Try Chrome or Edge.')
      return
    }

    if (listening) {
      recognitionRef.current?.stop()
      return
    }

    const recognition = new SpeechRecognitionCtor()
    recognition.continuous = false
    recognition.interimResults = false
    recognition.lang = 'en-US'

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript
      setInput(transcript)
      send(transcript)
    }
    recognition.onerror = () => {
      toast.error('Could not hear you clearly. Please try again.')
      setListening(false)
    }
    recognition.onend = () => setListening(false)

    recognitionRef.current = recognition
    recognition.start()
    setListening(true)
  }

  return (
    <div className="p-8 h-screen flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Virtual Gym Buddy</h1>
          <p className="text-gray-400 mt-1">Your AI companion for motivation and guidance</p>
        </div>
        <div className="flex items-center gap-4">
          {voiceSupported && (
            <button
              onClick={() => setVoiceReplyEnabled(v => !v)}
              title={voiceReplyEnabled ? 'Voice replies on' : 'Voice replies off'}
              className={`flex items-center gap-2 text-sm transition-colors ${voiceReplyEnabled ? 'text-primary' : 'text-gray-500 hover:text-white'}`}
            >
              {voiceReplyEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
              Voice replies
            </button>
          )}
          <button onClick={clearChat} className="flex items-center gap-2 text-sm text-gray-500 hover:text-red-400 transition-colors">
            <Trash2 size={14} /> Clear chat
          </button>
        </div>
      </div>

      <div className="flex-1 glass rounded-xl flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-16">
              <Bot size={48} className="text-primary mx-auto mb-4" />
              <p className="text-white font-display font-semibold text-xl">Hey {user?.name?.split(' ')[0]}! 👋</p>
              <p className="text-gray-400 mt-2 text-sm">I'm FitBot, your AI gym companion. Tell me how you're feeling, ask for motivation, or just tap the mic and talk to me!</p>
            </div>
          )}
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.role !== 'user' && (
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3 mt-1 flex-shrink-0">
                  <Bot size={14} className="text-primary" />
                </div>
              )}
              <div className={`max-w-lg px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-primary text-dark font-medium rounded-br-sm'
                  : 'bg-muted text-gray-200 rounded-bl-sm'
              }`}>
                {msg.content}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center"><Bot size={14} className="text-primary" /></div>
              <div className="bg-muted rounded-2xl px-4 py-3 flex gap-1">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <div className="border-t border-gray-800 p-4 flex gap-3">
          {voiceSupported && (
            <button
              onClick={toggleListening}
              title={listening ? 'Stop listening' : 'Speak to FitBot'}
              className={`p-3 rounded-xl transition-colors flex-shrink-0 ${
                listening ? 'bg-red-500 text-white animate-pulse' : 'bg-muted text-gray-400 hover:text-white'
              }`}
            >
              {listening ? <MicOff size={18} /> : <Mic size={18} />}
            </button>
          )}
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && send()}
            placeholder={listening ? 'Listening...' : 'Ask your gym buddy anything...'}
            className="flex-1 bg-muted border border-gray-700 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary"
          />
          <button onClick={() => send()} disabled={loading || !input.trim()}
            className="bg-primary text-dark p-3 rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50">
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  )
}
