import { useEffect, useRef, useState } from 'react'
import { apiFetch } from '../api/client'
import { TrendingUp, Download } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import toast from 'react-hot-toast'

interface ChartPoint { date: string; avg_score: number }
interface Report {
  chart_data: ChartPoint[]
  total_sessions: number
  overall_avg_score: number
  top_exercise: string
  sessions_this_week: number
}

export default function PerformancePage() {
  const [report, setReport] = useState<Report | null>(null)
  const [message, setMessage] = useState('')
  const [exporting, setExporting] = useState(false)
  const reportRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    apiFetch('/trainer/weekly-report')
      .then(d => {
        if (d.report) setReport(d.report)
        else setMessage(d.message)
      })
      .catch(() => setMessage('Failed to load report'))
  }, [])

  const exportPdf = async () => {
    if (!reportRef.current || !report) return
    setExporting(true)
    try {
      const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([
        import('html2canvas'),
        import('jspdf'),
      ])
      const canvas = await html2canvas(reportRef.current, { backgroundColor: '#000000', scale: 2 })
      const imgData = canvas.toDataURL('image/png')
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' })
      const pageWidth = pdf.internal.pageSize.getWidth()
      const imgWidth = pageWidth - 48
      const imgHeight = (canvas.height * imgWidth) / canvas.width
      pdf.setFontSize(18)
      pdf.text('FitAI — Weekly Performance Report', 24, 36)
      pdf.addImage(imgData, 'PNG', 24, 52, imgWidth, imgHeight)
      pdf.save('fitai-weekly-report.pdf')
    } catch {
      toast.error('Could not generate PDF. Please try again.')
    } finally {
      setExporting(false)
    }
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-white mb-2">Pose-to-Performance Analyzer</h1>
          <p className="text-gray-400">Weekly performance scores derived from your AI trainer sessions</p>
        </div>
        {report && (
          <button
            onClick={exportPdf}
            disabled={exporting}
            className="flex items-center gap-2 bg-primary text-dark font-semibold px-4 py-2.5 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 flex-shrink-0"
          >
            <Download size={16} /> {exporting ? 'Exporting...' : 'Export PDF'}
          </button>
        )}
      </div>

      {!report && (
        <div className="glass rounded-xl p-12 text-center">
          <TrendingUp size={48} className="text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">{message || 'Loading your performance data...'}</p>
          <p className="text-gray-600 text-sm mt-2">Complete AI Trainer sessions to generate your performance report</p>
        </div>
      )}

      {report && (
        <div ref={reportRef} className="space-y-6 bg-dark p-2">
          <div className="grid grid-cols-4 gap-4">
            {[
              { label: 'Sessions This Week', value: report.sessions_this_week },
              { label: 'Total Scored Sessions', value: report.total_sessions },
              { label: 'Avg Performance Score', value: `${report.overall_avg_score}/100` },
              { label: 'Top Exercise', value: report.top_exercise },
            ].map(({ label, value }) => (
              <div key={label} className="glass rounded-xl p-5 text-center">
                <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">{label}</p>
                <p className="text-2xl font-display font-bold text-primary capitalize">{value}</p>
              </div>
            ))}
          </div>

          <div className="glass rounded-xl p-6">
            <h3 className="font-display font-semibold text-white mb-6 flex items-center gap-2">
              <TrendingUp size={16} className="text-primary" />
              Performance Score Over Time
            </h3>
            {report.chart_data.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={report.chart_data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
                  <XAxis dataKey="date" tick={{ fill: '#6B7280', fontSize: 12 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: '#6B7280', fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{ background: '#111827', border: '1px solid #374151', borderRadius: 8 }}
                    labelStyle={{ color: '#9CA3AF' }}
                    itemStyle={{ color: '#00C896' }}
                  />
                  <Line type="monotone" dataKey="avg_score" stroke="#00C896" strokeWidth={2} dot={{ fill: '#00C896', r: 4 }} name="Avg Score" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-gray-500 text-sm text-center py-8">Not enough data yet to render chart</p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
