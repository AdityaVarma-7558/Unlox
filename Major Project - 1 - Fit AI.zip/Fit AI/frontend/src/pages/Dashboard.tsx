import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useAuth } from '../context/AuthContext'
import { apiFetch } from '../api/client'
import { Activity, Zap, TrendingUp, AlertTriangle } from 'lucide-react'

export default function Dashboard() {
  const { user } = useAuth()
  const [stats, setStats] = useState<Record<string, unknown> | null>(null)
  const [prediction, setPrediction] = useState<{ risk: string; prediction: string } | null>(null)

  useEffect(() => {
    apiFetch('/habit/stats').then(d => setStats(d.stats)).catch(() => {})
    apiFetch('/habit/predict').then(d => setPrediction(d)).catch(() => {})
  }, [])

  const riskColor = prediction?.risk === 'High' ? 'text-red-400' : prediction?.risk === 'Medium' ? 'text-yellow-400' : 'text-primary'

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-white">
          Welcome back, {user?.name?.split(' ')[0]} 👋
        </h1>
        <p className="text-gray-400 mt-1">Here's your fitness overview for today</p>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Active Days (30d)', value: stats ? `${(stats as { active_days?: number }).active_days ?? 0}` : '—', icon: Activity, color: 'text-primary' },
          { label: 'Total Sessions', value: stats ? `${(stats as { total_sessions?: number }).total_sessions ?? 0}` : '—', icon: Zap, color: 'text-accent' },
          { label: 'Consistency', value: stats ? `${(stats as { consistency_pct?: number }).consistency_pct ?? 0}%` : '—', icon: TrendingUp, color: 'text-green-400' },
          { label: 'Skip Risk', value: prediction?.risk ?? '—', icon: AlertTriangle, color: riskColor },
        ].map(({ label, value, icon: Icon, color }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: i * 0.06 }}
            className="glass rounded-xl p-5"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-gray-500 uppercase tracking-wide">{label}</span>
              <Icon size={16} className={color} />
            </div>
            <p className={`text-2xl font-display font-bold ${color}`}>{value}</p>
          </motion.div>
        ))}
      </div>

      <div className="glass rounded-xl p-6 mb-6">
        <h3 className="font-display font-semibold text-white mb-4 flex items-center gap-2">
          <AlertTriangle size={16} className="text-yellow-400" />
          Today's Motivation
        </h3>
        <p className="text-gray-300 text-sm leading-relaxed">
          {prediction?.prediction
          ? prediction.prediction.split('\n').filter(l => l.trim() && !l.trim().startsWith('RISK:')).join(' ')
          : 'Loading your personalized motivation...'}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="glass rounded-xl p-6">
          <h3 className="font-display font-semibold text-white mb-4">Your Profile</h3>
          <div className="space-y-2">
            {[
              ['Goal', user?.fitness_goal || 'Not set'],
              ['Diet', user?.dietary_preference || 'Not set'],
              ['Age', user?.age ? `${user.age} years` : 'Not set'],
              ['Weight', user?.weight ? `${user.weight} kg` : 'Not set'],
              ['Height', user?.height ? `${user.height} cm` : 'Not set'],
              ['BMI', user?.weight && user?.height ? `${(user.weight / ((user.height / 100) ** 2)).toFixed(1)}` : 'N/A'],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between text-sm">
                <span className="text-gray-500">{label}</span>
                <span className="text-white capitalize">{value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-xl p-6">
          <h3 className="font-display font-semibold text-white mb-4">Top Exercises</h3>
          {stats && (stats as { top_exercises?: [string, number][] }).top_exercises?.length ? (
            <div className="space-y-3">
              {((stats as { top_exercises?: [string, number][] }).top_exercises ?? []).map(([name, count]: [string, number]) => (
                <div key={name} className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-white capitalize">{name}</span>
                      <span className="text-gray-500">{count} sessions</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(100, count * 20)}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-sm">No workout data yet. Start training!</p>
          )}
        </div>
      </div>
    </div>
  )
}
