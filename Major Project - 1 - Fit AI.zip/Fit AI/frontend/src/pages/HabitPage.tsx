import { useState, useEffect } from 'react'
import { apiFetch } from '../api/client'
import { Activity, Plus, AlertTriangle } from 'lucide-react'

interface Log { id: number; exercise: string; reps?: number; sets?: number; duration_minutes?: number; performance_score?: number; logged_at: string }

export default function HabitPage() {
  const [logs, setLogs] = useState<Log[]>([])
  const [prediction, setPrediction] = useState<{ risk: string; prediction: string } | null>(null)
  const [stats, setStats] = useState<Record<string, unknown> | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ exercise: '', reps: '', sets: '', duration_minutes: '', notes: '' })

  const load = () => {
    apiFetch('/habit/logs?days=30').then(d => setLogs(d.logs)).catch(() => {})
    apiFetch('/habit/stats').then(d => setStats(d.stats)).catch(() => {})
    apiFetch('/habit/predict').then(d => setPrediction(d)).catch(() => {})
  }

  useEffect(() => { load() }, [])

  const logWorkout = async () => {
    if (!form.exercise.trim()) return
    setLoading(true)
    try {
      await apiFetch('/habit/log', {
        method: 'POST',
        body: JSON.stringify({ ...form, reps: Number(form.reps) || null, sets: Number(form.sets) || null, duration_minutes: Number(form.duration_minutes) || null })
      })
      setForm({ exercise: '', reps: '', sets: '', duration_minutes: '', notes: '' })
      setShowForm(false)
      load()
    } catch {}
    finally { setLoading(false) }
  }

  const riskColor = prediction?.risk === 'High' ? 'bg-red-500/10 border-red-500/30 text-red-400' : prediction?.risk === 'Medium' ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400' : 'bg-primary/10 border-primary/30 text-primary'

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">AI Habit Tracker</h1>
          <p className="text-gray-400 mt-1">Behavioral analysis and workout pattern prediction</p>
        </div>
        <button onClick={() => setShowForm(s => !s)} className="flex items-center gap-2 bg-primary text-dark font-semibold px-4 py-2.5 rounded-lg text-sm hover:bg-primary/90 transition-colors">
          <Plus size={16} /> Log Workout
        </button>
      </div>

      {showForm && (
        <div className="glass rounded-xl p-6 mb-6">
          <h3 className="font-display font-semibold text-white mb-4">Log a Workout</h3>
          <div className="grid grid-cols-4 gap-3 mb-3">
            <input placeholder="Exercise name *" value={form.exercise} onChange={e => setForm(f => ({ ...f, exercise: e.target.value }))}
              className="col-span-2 bg-dark border border-gray-700 rounded-lg px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
            <input type="number" placeholder="Reps" value={form.reps} onChange={e => setForm(f => ({ ...f, reps: e.target.value }))}
              className="bg-dark border border-gray-700 rounded-lg px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
            <input type="number" placeholder="Sets" value={form.sets} onChange={e => setForm(f => ({ ...f, sets: e.target.value }))}
              className="bg-dark border border-gray-700 rounded-lg px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
          </div>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <input type="number" placeholder="Duration (minutes)" value={form.duration_minutes} onChange={e => setForm(f => ({ ...f, duration_minutes: e.target.value }))}
              className="bg-dark border border-gray-700 rounded-lg px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
            <input placeholder="Notes (optional)" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="bg-dark border border-gray-700 rounded-lg px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
          </div>
          <button onClick={logWorkout} disabled={loading || !form.exercise.trim()}
            className="bg-primary text-dark font-semibold px-6 py-2.5 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50">
            {loading ? 'Saving...' : 'Save Workout'}
          </button>
        </div>
      )}

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-4">
          {prediction && (
            <div className={`border rounded-xl p-5 ${riskColor}`}>
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle size={16} />
                <span className="font-semibold text-sm">Skip Risk: {prediction.risk}</span>
              </div>
              <p className="text-sm opacity-80 leading-relaxed">
                {prediction.prediction.split('\n').filter(l => l.trim() && !l.trim().startsWith('RISK:')).join(' ')}
              </p>
            </div>
          )}

          <div className="glass rounded-xl p-5">
            <h3 className="font-display font-semibold text-white mb-4 flex items-center gap-2">
              <Activity size={16} className="text-primary" /> Recent Workouts
            </h3>
            {logs.length === 0 ? (
              <p className="text-gray-500 text-sm text-center py-8">No workouts logged yet. Start tracking!</p>
            ) : (
              <div className="space-y-3">
                {logs.slice(0, 10).map(log => (
                  <div key={log.id} className="flex items-center justify-between bg-muted rounded-lg px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-white capitalize">{log.exercise}</p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {[log.sets && `${log.sets} sets`, log.reps && `${log.reps} reps`, log.duration_minutes && `${log.duration_minutes} min`].filter(Boolean).join(' · ')}
                      </p>
                    </div>
                    <div className="text-right">
                      {log.performance_score && <p className="text-sm text-primary font-semibold">{log.performance_score}/100</p>}
                      <p className="text-xs text-gray-500">{new Date(log.logged_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-4">
          {stats && (
            <>
              {[
                { label: 'Active Days', value: `${(stats as { active_days?: number }).active_days ?? 0} / 30` },
                { label: 'Consistency', value: `${(stats as { consistency_pct?: number }).consistency_pct ?? 0}%` },
                { label: 'Total Sessions', value: `${(stats as { total_sessions?: number }).total_sessions ?? 0}` },
                { label: 'Avg Score', value: `${(stats as { avg_performance_score?: number }).avg_performance_score ?? 0}` },
              ].map(({ label, value }) => (
                <div key={label} className="glass rounded-xl p-5 text-center">
                  <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">{label}</p>
                  <p className="text-2xl font-display font-bold text-primary">{value}</p>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
