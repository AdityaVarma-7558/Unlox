import { useState } from 'react'
import { apiFetch } from '../api/client'
import { Map, Trophy, Building2 } from 'lucide-react'

type Tab = 'programs' | 'challenge' | 'gyms'

export default function RecommenderPage() {
  const [tab, setTab] = useState<Tab>('programs')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')
  const [form, setForm] = useState({
    goal: '', experience: '', days_per_week: '',
    session_minutes: '', equipment: '',
    level: '', focus: '',
    location: '', budget: '', preferred_time: ''
  })

  const fetch = async (endpoint: string, body: object) => {
    setLoading(true); setResult('')
    try {
      const d = await apiFetch(endpoint, { method: 'POST', body: JSON.stringify(body) })
      setResult(d.programs || d.challenge || d.advice)
    } catch (e: unknown) { setResult('Error: ' + (e instanceof Error ? e.message : String(e))) }
    finally { setLoading(false) }
  }

  return (
    <div className="p-8">
      <h1 className="text-3xl font-display font-bold text-white mb-2">Gym Recommender & Planner</h1>
      <p className="text-gray-400 mb-8">Personalized programs, challenges, and gym guidance</p>

      <div className="flex gap-2 mb-6 p-1 bg-muted rounded-lg w-fit">
        {([['programs', 'Programs'], ['challenge', '30-Day Challenge'], ['gyms', 'Find Gyms']] as [Tab, string][]).map(([t, label]) => (
          <button key={t} onClick={() => { setTab(t); setResult('') }}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${tab === t ? 'bg-primary text-dark' : 'text-gray-400 hover:text-white'}`}>
            {label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="glass rounded-xl p-6 space-y-4">
          {tab === 'programs' && (
            <>
              <h3 className="font-display font-semibold text-white flex items-center gap-2"><Map size={16} className="text-primary" /> Program Finder</h3>
              {[
                { label: 'Goal', key: 'goal', options: ['Weight loss', 'Muscle gain', 'Endurance', 'Flexibility', 'General fitness'] },
                { label: 'Experience', key: 'experience', options: ['Beginner', 'Intermediate', 'Advanced'] },
                { label: 'Equipment', key: 'equipment', options: ['No equipment', 'Basic gym', 'Full gym', 'Home gym'] },
              ].map(({ label, key, options }) => (
                <select key={key} value={form[key as keyof typeof form]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary">
                  <option value="">{label}</option>
                  {options.map(o => <option key={o} value={o.toLowerCase()}>{o}</option>)}
                </select>
              ))}
              <div className="grid grid-cols-2 gap-3">
                <input type="number" placeholder="Days/week" value={form.days_per_week} onChange={e => setForm(f => ({ ...f, days_per_week: e.target.value }))}
                  className="bg-dark border border-gray-700 rounded-lg px-3 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
                <input type="number" placeholder="Min/session" value={form.session_minutes} onChange={e => setForm(f => ({ ...f, session_minutes: e.target.value }))}
                  className="bg-dark border border-gray-700 rounded-lg px-3 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
              </div>
              <button onClick={() => fetch('/recommender/programs', form)} disabled={loading}
                className="w-full bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50">
                {loading ? 'Finding programs...' : 'Get Programs'}
              </button>
            </>
          )}

          {tab === 'challenge' && (
            <>
              <h3 className="font-display font-semibold text-white flex items-center gap-2"><Trophy size={16} className="text-primary" /> 30-Day Challenge</h3>
              {[
                { label: 'Level', key: 'level', options: ['Beginner', 'Intermediate', 'Advanced'] },
                { label: 'Focus', key: 'focus', options: ['Full body', 'Upper body', 'Lower body', 'Core', 'Cardio'] },
              ].map(({ label, key, options }) => (
                <select key={key} value={form[key as keyof typeof form]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary">
                  <option value="">{label}</option>
                  {options.map(o => <option key={o} value={o.toLowerCase()}>{o}</option>)}
                </select>
              ))}
              <button onClick={() => fetch('/recommender/challenge', form)} disabled={loading}
                className="w-full bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50">
                {loading ? 'Creating challenge...' : 'Generate Challenge'}
              </button>
            </>
          )}

          {tab === 'gyms' && (
            <>
              <h3 className="font-display font-semibold text-white flex items-center gap-2"><Building2 size={16} className="text-primary" /> Gym Finder</h3>
              <input placeholder="Your city / area" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
                className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-primary" />
              {[
                { label: 'Budget', key: 'budget', options: ['Budget', 'Moderate', 'Premium'] },
                { label: 'Preferred time', key: 'preferred_time', options: ['Morning', 'Afternoon', 'Evening', 'Flexible'] },
              ].map(({ label, key, options }) => (
                <select key={key} value={form[key as keyof typeof form]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  className="w-full bg-dark border border-gray-700 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-primary">
                  <option value="">{label}</option>
                  {options.map(o => <option key={o} value={o.toLowerCase()}>{o}</option>)}
                </select>
              ))}
              <button onClick={() => fetch('/recommender/gyms', form)} disabled={loading}
                className="w-full bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors disabled:opacity-50">
                {loading ? 'Loading...' : 'Get Guidance'}
              </button>
            </>
          )}
        </div>

        <div className="col-span-2 glass rounded-xl p-6 overflow-auto max-h-[70vh]">
          {loading && <div className="flex items-center gap-3 text-gray-400"><div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />Generating recommendations...</div>}
          {result && <pre className="text-sm text-gray-300 whitespace-pre-wrap font-body leading-relaxed">{result}</pre>}
          {!result && !loading && <div className="flex items-center justify-center h-full text-gray-600"><p>Your recommendations will appear here</p></div>}
        </div>
      </div>
    </div>
  )
}
