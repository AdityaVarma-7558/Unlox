import { useState, useRef, useCallback } from 'react'
import { apiFetch } from '../api/client'
import { Video, Square, RotateCcw } from 'lucide-react'
import toast from 'react-hot-toast'

const EXERCISES = ['bicep_curl', 'squat', 'pushup']

export default function TrainerPage() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const [active, setActive] = useState(false)
  const [exercise, setExercise] = useState('bicep_curl')
  const [reps, setReps] = useState(0)
  const [stage, setStage] = useState('')
  const [feedback, setFeedback] = useState('Select an exercise and start')
  const [score, setScore] = useState<number | null>(null)
  const [annotatedFrame, setAnnotatedFrame] = useState<string | null>(null)
  const repsRef = useRef(0)
  const stageRef = useRef('')

  const startCamera = async () => {
    let stream: MediaStream
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true })
    } catch {
      toast.error('Camera access denied. Please allow camera permissions and try again.')
      return
    }
    if (videoRef.current) videoRef.current.srcObject = stream
    setActive(true)
    setReps(0)
    repsRef.current = 0
    stageRef.current = ''
    setStage('')

    intervalRef.current = setInterval(async () => {
      if (!videoRef.current || !canvasRef.current) return
      const ctx = canvasRef.current.getContext('2d')
      if (!ctx) return
      canvasRef.current.width = videoRef.current.videoWidth
      canvasRef.current.height = videoRef.current.videoHeight
      ctx.drawImage(videoRef.current, 0, 0)
      const frameB64 = canvasRef.current.toDataURL('image/jpeg', 0.7).split(',')[1]

      try {
        const res = await apiFetch('/trainer/analyze', {
          method: 'POST',
          body: JSON.stringify({
            frame: frameB64,
            exercise,
            rep_count: repsRef.current,
            stage: stageRef.current
          })
        })
        repsRef.current = res.reps
        stageRef.current = res.stage
        setReps(res.reps)
        setStage(res.stage)
        setFeedback(res.feedback)
        setScore(res.score)
        if (res.annotated_frame) setAnnotatedFrame(res.annotated_frame)
      } catch {}
    }, 500)
  }

  const stopCamera = useCallback(async () => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop())
      videoRef.current.srcObject = null
    }
    setActive(false)

    if (repsRef.current > 0) {
      try {
        await apiFetch('/trainer/performance-score', {
          method: 'POST',
          body: JSON.stringify({
            exercise,
            reps: repsRef.current,
            avg_score: score ?? 70,
            duration_minutes: 5
          })
        })
      } catch {}
    }
  }, [exercise, score])

  const reset = () => { setReps(0); repsRef.current = 0; setAnnotatedFrame(null); setFeedback('Ready') }

  return (
    <div className="p-8">
      <h1 className="text-3xl font-display font-bold text-white mb-2">AI Gym Trainer</h1>
      <p className="text-gray-400 mb-8">Real-time pose detection and rep counting via your webcam</p>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 glass rounded-xl overflow-hidden">
          <div className="relative bg-black aspect-video">
            <video ref={videoRef} autoPlay playsInline muted className={`w-full h-full object-cover ${annotatedFrame ? 'hidden' : ''}`} />
            {annotatedFrame && (
              <img src={`data:image/jpeg;base64,${annotatedFrame}`} className="w-full h-full object-cover" alt="pose" />
            )}
            <canvas ref={canvasRef} className="hidden" />
            {!active && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <Video size={48} className="text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-500">Camera is off</p>
                </div>
              </div>
            )}
            {active && (
              <div className="absolute top-4 left-4 bg-black/60 rounded-lg px-3 py-1.5">
                <span className="text-primary text-sm font-medium">● LIVE</span>
              </div>
            )}
          </div>

          <div className="p-4 flex gap-3">
            {!active ? (
              <button onClick={startCamera} className="flex-1 bg-primary text-dark font-semibold py-3 rounded-lg text-sm hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                <Video size={16} /> Start Session
              </button>
            ) : (
              <button onClick={stopCamera} className="flex-1 bg-red-500 text-white font-semibold py-3 rounded-lg text-sm hover:bg-red-600 transition-colors flex items-center justify-center gap-2">
                <Square size={16} /> End Session
              </button>
            )}
            <button onClick={reset} className="px-4 py-3 bg-muted rounded-lg text-gray-400 hover:text-white transition-colors">
              <RotateCcw size={16} />
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="glass rounded-xl p-5">
            <label className="text-xs text-gray-500 uppercase tracking-wide block mb-3">Exercise</label>
            <div className="space-y-2">
              {EXERCISES.map(ex => (
                <button
                  key={ex}
                  onClick={() => !active && setExercise(ex)}
                  disabled={active}
                  className={`w-full text-left px-4 py-3 rounded-lg text-sm capitalize transition-all ${
                    exercise === ex ? 'bg-primary/20 text-primary border border-primary/30' : 'bg-muted text-gray-400 hover:text-white'
                  } disabled:opacity-50`}
                >
                  {ex.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="glass rounded-xl p-5 text-center">
            <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Reps</p>
            <p className="text-6xl font-display font-bold text-primary">{reps}</p>
            <p className="text-xs text-gray-500 mt-2 capitalize">{stage || 'waiting'}</p>
          </div>

          <div className="glass rounded-xl p-5">
            <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Feedback</p>
            <p className="text-sm text-white">{feedback}</p>
            {score !== null && (
              <div className="mt-3">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-gray-500">Form Score</span>
                  <span className="text-primary">{score}/100</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${score}%` }} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
