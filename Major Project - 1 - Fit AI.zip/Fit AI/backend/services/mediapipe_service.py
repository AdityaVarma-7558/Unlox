import cv2
import mediapipe as mp
import numpy as np
import base64
import json

mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

def calculate_angle(a, b, c):
    a, b, c = np.array(a), np.array(b), np.array(c)
    radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
    angle = np.abs(radians * 180.0 / np.pi)
    return 360 - angle if angle > 180 else angle

def analyze_frame(frame_b64: str, exercise: str, rep_count: int, stage: str):
    img_bytes = base64.b64decode(frame_b64)
    nparr = np.frombuffer(img_bytes, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(image_rgb)

        feedback = "No pose detected"
        angle = None
        new_stage = stage
        new_reps = rep_count
        score = 0

        if results.pose_landmarks:
            lm = results.pose_landmarks.landmark

            if exercise == "bicep_curl":
                shoulder = [lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x, lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
                elbow = [lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].x, lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
                wrist = [lm[mp_pose.PoseLandmark.LEFT_WRIST.value].x, lm[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
                angle = calculate_angle(shoulder, elbow, wrist)
                if angle > 160:
                    new_stage = "down"
                if angle < 30 and new_stage == "down":
                    new_stage = "up"
                    new_reps += 1
                score = 100 if 20 <= angle <= 170 else 60
                feedback = "Good form!" if score == 100 else "Keep elbow steady"

            elif exercise == "squat":
                hip = [lm[mp_pose.PoseLandmark.LEFT_HIP.value].x, lm[mp_pose.PoseLandmark.LEFT_HIP.value].y]
                knee = [lm[mp_pose.PoseLandmark.LEFT_KNEE.value].x, lm[mp_pose.PoseLandmark.LEFT_KNEE.value].y]
                ankle = [lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].x, lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].y]
                angle = calculate_angle(hip, knee, ankle)
                if angle > 160:
                    new_stage = "up"
                if angle < 90 and new_stage == "up":
                    new_stage = "down"
                    new_reps += 1
                score = 100 if angle < 95 else 70
                feedback = "Deep squat!" if score == 100 else "Go lower for full range"

            elif exercise == "pushup":
                shoulder = [lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x, lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
                elbow = [lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].x, lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
                wrist = [lm[mp_pose.PoseLandmark.LEFT_WRIST.value].x, lm[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
                angle = calculate_angle(shoulder, elbow, wrist)
                if angle > 160:
                    new_stage = "up"
                if angle < 90 and new_stage == "up":
                    new_stage = "down"
                    new_reps += 1
                score = 100 if angle < 95 else 65
                feedback = "Perfect depth!" if score == 100 else "Lower your chest more"

            mp_drawing.draw_landmarks(frame, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

        _, buffer = cv2.imencode(".jpg", frame)
        annotated_b64 = base64.b64encode(buffer).decode("utf-8")

        return {
            "annotated_frame": annotated_b64,
            "reps": new_reps,
            "stage": new_stage,
            "angle": round(angle, 1) if angle else None,
            "feedback": feedback,
            "score": score,
        }
