import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

model = None
load_error = None

GEMINI_MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


def load_model():
    global model, load_error

    if model is not None:
        return model

    if load_error is not None:
        raise RuntimeError(load_error)

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        load_error = "GEMINI_API_KEY is not set in .env. Get one at https://aistudio.google.com/apikey"
        raise RuntimeError(load_error)

    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(GEMINI_MODEL_NAME)
    return model


def _safe_generate(prompt, system=""):
    try:
        gemini = load_model()
    except RuntimeError as e:
        return f"[AI unavailable] {e}"

    try:
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        response = gemini.generate_content(
            full_prompt,
            generation_config={"temperature": 0.7, "max_output_tokens": 512},
        )
        return response.text
    except Exception as e:
        return f"[AI error] Something went wrong while generating a response: {e}"


def ask_gemini(prompt, system=""):
    return _safe_generate(prompt, system)


def ask_gemini_chat(history, system=""):
    try:
        gemini = load_model()
    except RuntimeError as e:
        return f"[AI unavailable] {e}"

    try:
        # Gemini uses "model" instead of "assistant", and no separate system turn
        # in the basic chat API — fold it into the first user message instead.
        gemini_history = []
        for i, msg in enumerate(history[:-1]):
            role = "model" if msg["role"] == "assistant" else "user"
            content = msg["content"]
            if i == 0 and system:
                content = f"{system}\n\n{content}"
            gemini_history.append({"role": role, "parts": [content]})

        chat = gemini.start_chat(history=gemini_history)

        last_message = history[-1]["content"]
        if not history[:-1] and system:
            last_message = f"{system}\n\n{last_message}"

        response = chat.send_message(
            last_message,
            generation_config={"temperature": 0.7, "max_output_tokens": 512},
        )
        return response.text
    except Exception as e:
        return f"[AI error] Something went wrong while generating a response: {e}"
