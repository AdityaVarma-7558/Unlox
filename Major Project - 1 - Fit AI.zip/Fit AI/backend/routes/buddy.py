from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models.user import User
from models.chat_message import ChatMessage
from services.gemini_service import ask_gemini_chat

buddy_bp = Blueprint("buddy", __name__, url_prefix="/api/buddy")

BUDDY_SYSTEM = """You are an enthusiastic, empathetic AI fitness companion named FitBot.
Your role is to:
- Motivate users to stay consistent with workouts
- Provide emotional support and celebrate their wins
- Give personalized advice based on their fitness goals
- Detect when users feel demotivated and respond with energy and positivity
- Track the emotional tone of conversations and adjust accordingly
- Occasionally use fitness-related humor to keep things light
Keep responses concise (2-4 sentences unless detailed advice is needed). Be warm, human, and encouraging."""

@buddy_bp.route("/chat", methods=["POST"])
@jwt_required()
def chat():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "User not found"}), 404
    data = request.get_json() or {}
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"error": "Message is required"}), 400

    history = ChatMessage.query.filter_by(user_id=user.id, module="buddy").order_by(ChatMessage.created_at).limit(20).all()
    chat_history = [{"role": m.role, "content": m.content} for m in history]
    chat_history.append({"role": "user", "content": message})

    system = f"{BUDDY_SYSTEM}\nUser profile: {user.name}, Goal: {user.fitness_goal or 'general fitness'}"
    reply = ask_gemini_chat(chat_history, system)

    db.session.add(ChatMessage(user_id=user.id, role="user", content=message, module="buddy"))
    db.session.add(ChatMessage(user_id=user.id, role="assistant", content=reply, module="buddy"))
    db.session.commit()

    return jsonify({"reply": reply}), 200

@buddy_bp.route("/history", methods=["GET"])
@jwt_required()
def get_history():
    user_id = int(get_jwt_identity())
    messages = ChatMessage.query.filter_by(user_id=user_id, module="buddy").order_by(ChatMessage.created_at).limit(50).all()
    return jsonify({"messages": [m.to_dict() for m in messages]}), 200

@buddy_bp.route("/clear", methods=["DELETE"])
@jwt_required()
def clear_history():
    user_id = int(get_jwt_identity())
    ChatMessage.query.filter_by(user_id=user_id, module="buddy").delete()
    db.session.commit()
    return jsonify({"message": "Chat history cleared"}), 200
