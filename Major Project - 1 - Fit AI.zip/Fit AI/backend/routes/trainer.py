from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models.workout_log import WorkoutLog
from models.user import User
from services.mediapipe_service import analyze_frame
from services.gemini_service import ask_gemini
from datetime import datetime, timedelta

trainer_bp = Blueprint("trainer", __name__, url_prefix="/api/trainer")

@trainer_bp.route("/analyze", methods=["POST"])
@jwt_required()
def analyze():
    data = request.get_json() or {}
    frame_b64 = data.get("frame")
    exercise = data.get("exercise", "bicep_curl")
    rep_count = data.get("rep_count", 0)
    stage = data.get("stage", "")

    if not frame_b64:
        return jsonify({"error": "Frame data is required"}), 400

    result = analyze_frame(frame_b64, exercise, rep_count, stage)
    return jsonify(result), 200

@trainer_bp.route("/performance-score", methods=["POST"])
@jwt_required()
def performance_score():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "User not found"}), 404
    data = request.get_json() or {}
    exercise = data.get("exercise", "unknown")
    reps = data.get("reps", 0)
    avg_angle_score = data.get("avg_score", 70)
    duration = data.get("duration_minutes", 10)

    score = round((avg_angle_score * 0.6) + (min(reps, 20) / 20 * 100 * 0.3) + (min(duration, 30) / 30 * 100 * 0.1), 1)

    log = WorkoutLog(
        user_id=user.id,
        exercise=exercise,
        reps=reps,
        duration_minutes=duration,
        performance_score=score,
    )
    db.session.add(log)
    db.session.commit()

    prompt = f"""
Give a 2-sentence performance review for this workout:
- Exercise: {exercise}
- Reps completed: {reps}
- Performance score: {score}/100
- Duration: {duration} minutes
Be encouraging but specific about improvement areas.
"""
    feedback = ask_gemini(prompt)
    return jsonify({"score": score, "feedback": feedback, "log_id": log.id}), 200

@trainer_bp.route("/weekly-report", methods=["GET"])
@jwt_required()
def weekly_report():
    user_id = int(get_jwt_identity())
    since = datetime.utcnow() - timedelta(days=7)
    logs = WorkoutLog.query.filter(
        WorkoutLog.user_id == user_id,
        WorkoutLog.logged_at >= since,
        WorkoutLog.performance_score.isnot(None)
    ).all()

    if not logs:
        return jsonify({"message": "No scored workouts this week yet", "report": None}), 200

    weekly_data = {}
    for log in logs:
        day = str(log.logged_at)[:10]
        if day not in weekly_data:
            weekly_data[day] = []
        weekly_data[day].append(log.performance_score)

    chart_data = [
        {"date": day, "avg_score": round(sum(scores) / len(scores), 1)}
        for day, scores in sorted(weekly_data.items())
    ]

    overall_avg = round(sum(l.performance_score for l in logs) / len(logs), 1)
    top_exercise = max(set(l.exercise for l in logs), key=lambda e: sum(1 for l in logs if l.exercise == e))

    return jsonify({
        "report": {
            "chart_data": chart_data,
            "total_sessions": len(logs),
            "overall_avg_score": overall_avg,
            "top_exercise": top_exercise,
            "sessions_this_week": len(logs),
        }
    }), 200
