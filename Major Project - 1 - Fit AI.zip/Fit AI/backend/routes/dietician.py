from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.user import User
from services.gemini_service import ask_gemini

dietician_bp = Blueprint("dietician", __name__, url_prefix="/api/dietician")

@dietician_bp.route("/plan", methods=["POST"])
@jwt_required()
def get_diet_plan():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "User not found"}), 404
    data = request.get_json() or {}

    bmi = None
    if user.weight and user.height:
        bmi = round(user.weight / ((user.height / 100) ** 2), 1)

    prompt = f"""
You are a professional dietician and calorie coach.
Create a detailed 7-day meal plan for the following user:
- Name: {user.name}
- Age: {user.age or 'Unknown'}
- Weight: {user.weight or 'Unknown'} kg
- Height: {user.height or 'Unknown'} cm
- BMI: {bmi or 'Unknown'}
- Fitness Goal: {user.fitness_goal or data.get('fitness_goal', 'General fitness')}
- Dietary Preference: {user.dietary_preference or data.get('dietary_preference', 'No restriction')}
- Allergies/Restrictions: {data.get('allergies', 'None')}

Provide:
1. Daily calorie target
2. Macro breakdown (protein/carbs/fats in grams)
3. 7-day meal plan (breakfast, lunch, dinner, snacks)
4. A grocery list
5. 3 key nutrition tips

Format it clearly with section headers.
"""
    result = ask_gemini(prompt)
    return jsonify({"plan": result, "bmi": bmi}), 200

@dietician_bp.route("/calories", methods=["POST"])
@jwt_required()
def log_calories():
    data = request.get_json() or {}
    food = data.get("food", "")
    if not food:
        return jsonify({"error": "Food item required"}), 400

    prompt = f"""
You are a nutrition expert. Provide the nutritional breakdown for: "{food}"
Return:
- Estimated calories
- Protein (g)
- Carbohydrates (g)
- Fats (g)
- Fiber (g)
- Key vitamins/minerals
- Whether it fits a {data.get('goal', 'general fitness')} diet goal
Keep it concise and factual.
"""
    result = ask_gemini(prompt)
    return jsonify({"analysis": result}), 200

@dietician_bp.route("/grocery", methods=["POST"])
@jwt_required()
def generate_grocery():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "User not found"}), 404
    data = request.get_json() or {}

    prompt = f"""
Generate a structured weekly grocery list for a person with:
- Goal: {user.fitness_goal or 'general fitness'}
- Dietary preference: {user.dietary_preference or 'no restriction'}
- Budget preference: {data.get('budget', 'moderate')}

Organize by: Proteins, Vegetables, Fruits, Grains, Dairy/Alternatives, Healthy Fats, Snacks.
Include estimated quantities for one person for one week.
"""
    result = ask_gemini(prompt)
    return jsonify({"grocery_list": result}), 200
