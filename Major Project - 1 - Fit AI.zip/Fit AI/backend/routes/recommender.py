from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.user import User
from services.gemini_service import ask_gemini

recommender_bp = Blueprint("recommender", __name__, url_prefix="/api/recommender")

@recommender_bp.route("/programs", methods=["POST"])
@jwt_required()
def recommend_programs():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "User not found"}), 404
    data = request.get_json() or {}

    prompt = f"""
You are a fitness program expert. Recommend 3 tailored workout programs for:
- Name: {user.name}
- Age: {user.age or 'Unknown'}
- Goal: {user.fitness_goal or data.get('goal') or 'general fitness'}
- Experience level: {data.get('experience') or 'beginner'}
- Available days per week: {data.get('days_per_week') or 3}
- Available equipment: {data.get('equipment') or 'basic gym'}
- Time per session: {data.get('session_minutes') or 45} minutes

For each program provide:
1. Program name
2. Duration (weeks)
3. Weekly schedule breakdown
4. Key exercises
5. Expected results
6. Difficulty rating (1-10)

Format clearly with headers for each program.
"""
    result = ask_gemini(prompt)
    return jsonify({"programs": result}), 200

@recommender_bp.route("/challenge", methods=["POST"])
@jwt_required()
def get_challenge():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "User not found"}), 404
    data = request.get_json() or {}

    prompt = f"""
Create a personalized 30-day fitness challenge for:
- Goal: {user.fitness_goal or 'general fitness'}
- Level: {data.get('level') or 'beginner'}
- Focus area: {data.get('focus') or 'full body'}

Structure it as:
- Week 1 (Foundation): daily tasks
- Week 2 (Building): daily tasks  
- Week 3 (Intensity): daily tasks
- Week 4 (Peak): daily tasks

Make it progressive, realistic and motivating.
"""
    result = ask_gemini(prompt)
    return jsonify({"challenge": result}), 200

@recommender_bp.route("/gyms", methods=["POST"])
@jwt_required()
def recommend_gyms():
    data = request.get_json() or {}
    location = data.get("location") or "your area"

    prompt = f"""
A fitness enthusiast in {location} is looking for gyms. Their preferences:
- Budget: {data.get('budget') or 'moderate'}
- Focus: {data.get('focus') or 'general fitness'}
- Preferred time: {data.get('preferred_time') or 'flexible'}

Provide:
1. What to look for in a gym based on their needs
2. Types of gyms that suit them (budget gym, boutique, CrossFit, etc.)
3. Key questions to ask when visiting
4. Red flags to avoid
5. Tips on negotiating membership fees

Note: Provide general guidance as real-time gym listings require a location service.
"""
    result = ask_gemini(prompt)
    return jsonify({"advice": result}), 200
