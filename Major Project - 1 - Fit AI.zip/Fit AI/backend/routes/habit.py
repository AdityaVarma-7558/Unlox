from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models.user import User
from models.workout_log import WorkoutLog
from services.gemini_service import ask_gemini
from datetime import datetime, timedelta

habit_bp = Blueprint("habit", __name__, url_prefix="/api/habit")

@habit_bp.route("/log", methods=["POST"])
@jwt_required()
def log_workout():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
    data = request.get_json() or {}
    if not data.get("exercise"):
        return jsonify({"error": "Exercise name is required"}), 400
    log = WorkoutLog(
        user_id=user_id,
        exercise=data["exercise"],
        reps=data.get("reps"),
        sets=data.get("sets"),
        duration_minutes=data.get("duration_minutes"),
        performance_score=data.get("performance_score"),
        notes=data.get("notes"),
    )
    db.session.add(log)
    db.session.commit()

    return jsonify({"log": log.to_dict()}), 201

@habit_bp.route("/logs", methods=["GET"])
@jwt_required()
def get_logs():
    user_id = int(get_jwt_identity())
    days = int(request.args.get("days", 30))
    since = datetime.utcnow() - timedelta(days=days)
    logs = WorkoutLog.query.filter(
        WorkoutLog.user_id == user_id,
        WorkoutLog.logged_at >= since
    ).order_by(WorkoutLog.logged_at.desc()).all()
    return jsonify({"logs": [l.to_dict() for l in logs]}), 200

@habit_bp.route("/predict", methods=["GET"])
@jwt_required()
def predict_skip():
    user = User.query.get(int(get_jwt_identity()))
    if not user:
        return jsonify({"error": "User not found"}), 404
    logs = WorkoutLog.query.filter_by(user_id=user.id).order_by(WorkoutLog.logged_at.desc()).limit(14).all()

    if not logs:
        return jsonify({"prediction": "No workout history yet. Start logging to get predictions!", "risk": "unknown"}), 200

    log_summary = "\n".join([f"- {l.exercise} on {str(l.logged_at)[:10]}" for l in logs])
    today = datetime.utcnow().strftime("%A, %B %d")

    prompt = f"""
You are a behavioral AI fitness coach analyzing workout patterns.
User: {user.name}, Goal: {user.fitness_goal or 'general fitness'}
Today: {today}

Recent workout history (last 14 days):
{log_summary}

Analyze the pattern and:
1. Predict the skip risk for today (Low / Medium / High)
2. Identify the pattern (e.g., skips weekends, drops off mid-week)
3. Give a short motivational nudge (2 sentences max)
4. Suggest the best time to work out today

Start your response with "RISK: Low", "RISK: Medium", or "RISK: High" on its own line, then provide the analysis.
"""
    result = ask_gemini(prompt)
    risk = "Medium"
    for line in result.split("\n"):
        if line.startswith("RISK:"):
            risk = line.replace("RISK:", "").strip()
            break
    return jsonify({"prediction": result, "risk": risk}), 200

@habit_bp.route("/stats", methods=["GET"])
@jwt_required()
def get_stats():
    user_id = int(get_jwt_identity())
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
    since = datetime.utcnow() - timedelta(days=30)
    logs = WorkoutLog.query.filter(
        WorkoutLog.user_id == user_id,
        WorkoutLog.logged_at >= since
    ).all()

    if not logs:
        return jsonify({"stats": {}, "message": "No workouts logged yet"}), 200

    total = len(logs)
    unique_days = len(set(str(l.logged_at)[:10] for l in logs))
    scored = [l.performance_score for l in logs if l.performance_score]
    avg_score = round(sum(scored) / len(scored), 1) if scored else 0
    exercises = {}
    for l in logs:
        exercises[l.exercise] = exercises.get(l.exercise, 0) + 1

    return jsonify({
        "stats": {
            "total_sessions": total,
            "active_days": unique_days,
            "consistency_pct": round((unique_days / 30) * 100, 1),
            "avg_performance_score": avg_score,
            "top_exercises": sorted(exercises.items(), key=lambda x: x[1], reverse=True)[:5],
        }
    }), 200
