# FitAI Backend

Flask API powering FitAI, using the **Gemini API** for all AI features (diet plans, gym
buddy chat, program recommendations, trainer feedback, habit predictions).

## Setup

```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Copy  `.env` and add your Gemini API key (free at https://aistudio.google.com/apikey):

```
JWT_SECRET_KEY=change-this-to-a-random-secret
GEMINI_API_KEY=your-actual-key-here
GEMINI_MODEL=gemini-2.5-flash
FLASK_ENV=development
FLASK_DEBUG=1
```

Run it:

```bash
python app.py
```

Serves on `http://localhost:5000`. Health check at `GET /api/health`.

## Modules

- `routes/auth.py` — register/login/JWT, profile
- `routes/trainer.py` — pose analysis, rep counting, performance scoring
- `routes/dietician.py` — meal plans, calorie logging, grocery lists
- `routes/buddy.py` — conversational gym buddy chat
- `routes/habit.py` — workout logging, skip-risk prediction, stats
- `routes/recommender.py` — program finder, 30-day challenges, gym guidance

All AI calls route through `services/gemini_service.py`. If a response looks cut off,
`max_output_tokens` in that file controls response length.