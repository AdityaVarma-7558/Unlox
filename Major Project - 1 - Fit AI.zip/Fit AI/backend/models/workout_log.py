from extensions import db

class WorkoutLog(db.Model):
    __tablename__ = "workout_logs"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    exercise = db.Column(db.String(100), nullable=False)
    reps = db.Column(db.Integer, nullable=True)
    sets = db.Column(db.Integer, nullable=True)
    duration_minutes = db.Column(db.Float, nullable=True)
    performance_score = db.Column(db.Float, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    logged_at = db.Column(db.DateTime, server_default=db.func.now())

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "exercise": self.exercise,
            "reps": self.reps,
            "sets": self.sets,
            "duration_minutes": self.duration_minutes,
            "performance_score": self.performance_score,
            "notes": self.notes,
            "logged_at": str(self.logged_at),
        }
