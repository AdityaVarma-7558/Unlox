**TELCO CUSTOMER CHURN PREDICTION: LOGISTIC REGRESSION**



**PROJECT OVERVIEW:**

This project applies Logistic Regression to a classification problem using the Telco Customer Churn dataset. It demonstrates a machine learning workflow including Exploratory Data Analysis (EDA), data preprocessing, model building, evaluation, and interpretation.



**PROJECT STRUCTURE:**

\- Dataset.csv: The raw Telco Customer Churn dataset.

\- Minor\_Project\_4.ipynb: Jupyter Notebook containing the code.

\- Report.pdf: Formal technical report of the findings.

\- README.txt: Project documentation.

\- charts/: Exported visualizations (Histograms, Heatmaps, ROC Curve).



**REQUIREMENTS:**

To run this project, you will need Python and the following libraries:

pandas, numpy, matplotlib, seaborn and sklearn



**EXECUTION INSTRUCTIONS:**

1\. Place Dataset.csv in the root directory.

2\. Open Minor\_Project\_4.ipynb in a notebook environment.

3\. Run all cells in order.



**KEY INSIGHTS:**

\- Algorithm: Logistic Regression

\- Accuracy: Approx. 80% baseline accuracy.

\- Findings: Month-to-month contracts and high monthly charges drive customer churn. High tenure and two-year contracts drive customer retention.

